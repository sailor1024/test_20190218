<template>
  <div>
    <Row class="box" >
      <Col class="item" span="8">
        <div class="itembox">
          <div class="icon icon1">
          </div>
          <div class="info">
            <h4>{{this.$store.state.statobj.looknum}}</h4>
            <p>永久</p>
          </div>
          <div class="some">
            <Tooltip content="说明">
              <Icon size="17" class="iconspan" color="#888" type="help-circled" @click="forever(foreverMsg)"></Icon>
            </Tooltip>
          </div>
        </div>
      </Col>
      <Col class="look" span="8">
        <div class="itembox" style="margin-left:11px">
          <div class="icon icon2">
          </div>
          <div class="info">
            <h4>{{this.$store.state.statobj.lookplay}}</h4>
            <p>浏览</p>
          </div>
          <div class="some">
            <Tooltip content="说明">
              <Icon size="17" class="iconspan" color="#888" type="help-circled" @click="forever(foreverImpression)"></Icon>
            </Tooltip>
          </div>
        </div>
      </Col>
      <Col class="line" span="8">
        <div class="itembox" style="margin-left:11px">
          <div class="icon icon3" >
          </div>
          <div class="info">
            <h4>{{this.$store.state.statobj.lookuser}}</h4>
            <p>访问</p>
          </div>
          <div class="some">
            <Tooltip content="说明">
              <Icon size="17" class="iconspan" color="#888" type="help-circled" @click="forever(foreverVisit)"></Icon>
            </Tooltip>
          </div>
        </div>
      </Col>
    </Row>
    <stainumConPop v-if="stainumShow" :json="json"/>
  </div>
</template>

<script>
import stainumConPop from './stainumConPop'
export default {
  name: 'stainumCon',
  data () {
    return {
      stainumShow: this.$store.state.stainumTo,
      json: '',
      // 永久信息
      foreverMsg: [{
        title: '永久',
        msg: '自2018年6月1日起收集统计数据。在该日期之前创建的空间将显示自2018年6月1日以来收集的数据'
      }],
      // 印象信息
      foreverImpression: [{
        title: '浏览',
        msg: '当有人查看包含3D空间的页面或点击公共空间链接时展示的浏览人数。'
      }],
      // 访问信息
      foreverVisit: [{
        title: '访问',
        msg: '在空间成功加载时显示的访问量。'
      }]
    }
  },
  methods: {
    forever: function (data) {
      this.json = data
      this.stainumShow = true
      this.$store.dispatch('stainumTo', true)
    }
  },
  computed: {
    stainumTo () {
      return this.$store.state.stainumTo
    }
  },
  watch: {
    stainumTo (newVal, oldVal) {
      this.$data.stainumShow = newVal
    }
  },
  components: {
    stainumConPop
  }
}
</script>

<style lang="scss" scoped>
.box{
  background-color: white;
  padding: 15px 8px;
  margin: 0 !important;
  .item{
    height: 110px;
  }
  .look{
    height: 110px;
  }
  .line{
    height: 110px;
  }
  .itembox{
    border:1px solid rgba(231,231,231,1);
    height: 100%;
    display: flex;
    .icon{
      width: 87px;
      background-color: #F1F1F1;
      background-position: center center;
      background-repeat: no-repeat;
      background-size: 40px 40px;
    }
    .icon1{
      background-image: url('../../assets/images/stat_hezi.png');
    }
    .icon2{
      background-image: url('../../assets/images/stat_file.png');
    }
    .icon3{
      background-image: url('../../assets/images/stat_zexian.png');
    }
    .info{
      flex: 1;
      margin-left: 13px;
      h4{
        height:38px;
        font-size:32px;
        font-family:Helvetica-Light;
        color:rgba(136,136,136,1);
        line-height:38px;
        margin-top: 23px;
      }
      p{
        height:20px;
        font-size:14px;
        font-family:PingFang-SC-Medium;
        color:rgba(136,136,136,1);
        line-height:20px;
        margin-top: 3px;
      }
    }
    .some{
      width: 36px;
      .iconspan{
        margin-top: 10px;
        margin-left:10px;
        cursor: pointer;
      }
    }
  }
}
</style>

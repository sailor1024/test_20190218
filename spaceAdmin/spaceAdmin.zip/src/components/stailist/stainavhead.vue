<template>
  <div >
    <Row class="itembox">
      <Col class="item" span="12">
        <div class="content">
          <Dropdown class="menue" @on-click="select" trigger="click">
            <a style="color: #00A1FF" href="javascript:void(0)">
                {{res}}
                <Icon class="icon" type="arrow-down-b" color="#00A1FF" size="16px"></Icon>
            </a>
            <DropdownMenu slot="list">
                <DropdownItem name="创建日期" class="slide">创建日期</DropdownItem>
                <DropdownItem name="名称" class="slide">名称</DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </div>
      </Col>
      <Col class="item" span="3">
        <div class="numspan">
          <span>天数</span>
        </div>
      </Col>
      <Col class="item" span="3">
        <div class="numspan"><span>浏览</span></div>
      </Col>
      <Col class="item" span="3">
        <div class="numspan"><span>访问</span></div>
      </Col>
      <Col class="item" span="3">
        <div class="numspan"><span>特殊访客</span></div>
      </Col>
    </Row>
  </div>
</template>

<script>
export default {
  name: 'stainavhead',
  data () {
    return {
      res: '创建日期'
    }
  },
  methods: {
    select: function (name) {
      this.res = name
    }
  }
}
</script>

<style lang="scss" scoped>
.menue{
  font-size:14px;
  font-family:PingFangSC-Regular;
  color:#00A1FF;
  margin-left: 14px;
  padding: 8px 0px 9px 0px;
  a{
    .icon{
      transform: rotate(180deg);
    }
  }
  a:hover{
    transform: rotate(0deg);
  }
  .slide {
    border-bottom:1px solid #e0e0e0 !important;
  }
  .slide:last-child {
    border-bottom:0 !important;
  }
  .slide:hover {
    color: rgb(0, 161, 255)
  }
}
.itembox{
  // height: 25px;
  padding: 2px 0px;
  background-color: white;
  border-bottom:1px solid rgba(231,231,231,1);
  .item{
    height: 100%;
    .numspan{
      span{
        display: inline-block;
        height:31px;
        font-size:12px;
        font-family:PingFangSC-Regular;
        color:rgba(176,176,176,1);
        line-height:31px;
      }
    }
  }
}
</style>

<template>
  <div>
    <!-- <div class="titleheader">
      <div class="left">
        <a>所有项目</a>
      </div>
      <div class="right">
        <a>选择文件夹</a>
      </div>
    </div> -->
    <div class="typebox">
      <div class="left">
        <a>筛选</a>
        <!-- <a v-for="(json,index) in list" :key="index" :class="json.isactive === true ? 'active' : ''" data-type="json.type" @click="selectfunc">{{json.name}}</a> -->
        <a :class="select1 === true ? 'active' : ''" @click="selectfunc1">永久</a>
        <a :class="select2 === true ? 'active' : ''" @click="selectfunc2">30天内</a>
        <a :class="select3 === true ? 'active' : ''" @click="selectfunc3">7天内</a>
      </div>
      <div class="right">
        <a>导出数据</a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'stailistHeader',
  data () {
    return {
      'select1': true,
      'select2': false,
      'select3': false
    }
  },
  created () {
    this.loadsoure(0)
  },
  methods: {
    selectfunc1 () {
      this.allnoselect()
      this.select1 = true
      this.loadsoure(0)
    },
    selectfunc2 () {
      this.allnoselect()
      this.select2 = true
      this.loadsoure(1)
    },
    selectfunc3 () {
      this.allnoselect()
      this.select3 = true
      this.loadsoure(2)
    },
    allnoselect () {
      this.select1 = false
      this.select2 = false
      this.select3 = false
    },
    loadsoure (type) {
      this.$http.post('index/index/count_project', {
        'type': type,
        'userid': this.$store.state.userInfo.id
      }).then((res) => {
        let data = res.data
        this.$store.dispatch('statobj', data.data)
      }).catch(() => {
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.titleheader{
  background-color: white;
  height: 70px;
  display: flex;
  border-bottom: 1px solid rgb(231, 231, 231);
  .left{
    flex: 1;
    position: relative;
    a{
      display: block;
      font-size:18px;
      font-family:PingFang-SC-Medium;
      color:rgba(0,161,255,1);
      position: absolute;
      bottom: 6px;
      left: 40px;
      &::after{
        contain: ' ';
        display: block;
        position: absolute;
        height: 5px;
        width: 111px;
        background-color: #00A1FF;
        bottom: 0px;
        left: 0px;
        right: 0px;
      }
    }
  }
  .right{
    width: 262px;
    border-left: 1px solid rgb(231, 231, 231);
    a{
      display: block;
      width: 231px;
      height: 34px;
      background-color: #00A1FF;
      font-size:14px;
      line-height: 34px;
      font-family:PingFangSC-Regular;
      color:rgba(255,255,255,1);
      text-align: center;
      margin: 0 auto;
      border-radius: 5px;
      margin-top: 17px;
    }
  }
}
.typebox{
  display: flex;
  height: 66px;
  overflow: hidden;
  .left{
    flex: 1;
    a{
      margin-top: 16px;
      display: inline-block;
      vertical-align: top;
      height:34px;
      line-height: 34px;
      font-size:14px;
      font-family:PingFang-SC-Medium;
      color:rgba(98,98,98,1);
      padding: 0 31px;
    }
    .active{
      color: white;
      background-color: #00A1FF;
      border-radius: 2px;
    }
  }
  .right{
    width: 262px;
    a{
      display: block;
      width: 231px;
      height: 34px;
      background-color: #00A1FF;
      font-size:14px;
      line-height: 34px;
      font-family:PingFangSC-Regular;
      color:#fff;
      text-align: center;
      margin: 0 auto;
      border-radius: 5px;
      margin-top: 17px;
    }
  }
}
</style>

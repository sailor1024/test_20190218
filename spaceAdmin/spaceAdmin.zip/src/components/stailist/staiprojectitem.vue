<template>
  <div>
    <Row class="itembox">
      <Col class="item" span="12">
        <div class="content">
          <div class="left" :style="backimg"></div>
          <div class="right">
            <div @click="fly" style="margin-bottom:10px;margin-top:35px;font-size:18px;cursor:pointer" title="点击查看空间详情">{{json.title}}</div>
            <p>{{desbute}}</p>
          </div>
        </div>
      </Col>
      <Col class="item" span="3">
        <div class="numspan">
          <span>{{numday}}</span>
        </div>
      </Col>
      <Col class="item" span="3">
        <div class="numspan"><span>{{json.looknum}}</span></div>
      </Col>
      <Col class="item" span="3">
        <div class="numspan"><span>{{json.lookplay}}</span></div>
      </Col>
      <Col class="item" span="3">
        <div class="numspan"><span>{{json.lookuser}}</span></div>
      </Col>
    </Row>
  </div>
</template>

<script>
export default {
  name: 'staiprojectitem',
  props: ['json'],
  created () {
  },
  computed: {
    desbute () {
      return '由' + this.json.username.lastname + this.json.username.famailname + '创建于' + this.format(this.json.create_time)
    },
    backimg () {
      let url = ''
      if (this.json.marker_image) {
        url = this.$imgURL + this.json.marker_image
      } else {
        url = this.$imgURL + '/assets/img/2.jpg'
      }
      return {
        'backgroundImage': 'url(' + url + ')'
      }
    },
    numday () {
      let time = Math.ceil(new Date().getTime() / 1000)
      let num = Math.ceil((time - this.json.create_time) / (24 * 60 * 60))
      return num
    }
  },
  methods: {
    fly () {
      this.$router.push({
        path: '/home',
        query: {
          id: this.json.id
        }
      })
    },
    format (time) {
      let date = new Date(time * 1000)
      let y = date.getFullYear() + ''
      let m = date.getMonth() + 1
      let d = date.getDate()
      m = m > 10 ? m : '0' + m
      d = d > 10 ? d : '' + d
      return y + '年' + m + '月' + d + '日'
    }
  }
}
</script>

<style lang="scss" scoped>
.itembox{
  height: 116px;
  background-color: white;
  border-bottom:1px solid rgba(231,231,231,1);
  .item{
    height: 100%;
    .numspan{
      span{
        display: inline-block;
        width:11px;
        height:25px;
        font-size:18px;
        font-family:PingFangSC-Regular;
        color:rgba(176,176,176,1);
        line-height:25px;
        margin-top: 23px;
        text-indent: 0.5em;
      }
    }
    .content{
      display: flex;
      .left{
        width: 101px;
        height: 70px;
        margin-left: 15px;
        margin-top: 24px;
        background-position: center center;
        background-repeat: no-repeat;
        background-size: cover;
        background-color: antiquewhite;
      }
      .right{
        flex: 1;
        margin-left: 16px;
        h4{
          width: 100%;
          height:22px;
          font-size:18px;
          font-family:Helvetica;
          color:rgba(0,161,255,1);
          line-height:22px;
          margin-top: 28px;
          overflow: hidden;
          text-overflow:ellipsis;
          white-space: nowrap;
          cursor: pointer;
        }
        p{
          height:17px;
          font-size:12px;
          font-family:PingFangSC-Regular;
          color:rgba(176,176,176,1);
          line-height:17px;
          margin-top: 5px;
        }
      }
    }
  }
}
</style>

<template>
  <div>
    <stailistHeader />
    <stainumCon />
    <staiprojectlist />
    <div class="pagediv">
      <Page @on-change="valuechange" class="pagebox" :total="sums" v-if="sums !== 0"></Page>
      <nosoureComponent v-else/>
    </div>
  </div>
</template>

<script>
import stailistHeader from './stailistHeader'
import stainumCon from './stainumCon'
import staiprojectlist from './staiprojectlist'
import nosoureComponent from '../common/nosoureComponent'
export default {
  name: 'staIContent',
  data () {
    return {
      sums: 0
    }
  },
  components: {
    stailistHeader,
    stainumCon,
    staiprojectlist,
    nosoureComponent
  },
  computed: {
    sum: function () {
      return this.$store.state.statobj
    }
  },
  watch: {
    sum (newVal) {
      this.sums = newVal.list.length
    }
  },
  methods: {
    valuechange (page) {
      this.$store.dispatch('stanum', page)
    }
  }
}
</script>

<style lang="scss" scoped>
.pagediv{
  text-align: center;
  margin-bottom:60px;
  .pagebox{
    padding: 13px;
    margin: 0 auto;
    display: inline-block;
  }
}
</style>

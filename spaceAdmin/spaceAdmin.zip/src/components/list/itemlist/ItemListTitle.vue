<style lang="scss">
.itemList-titleComponent{
  .itemList-title{
      height:37px;
      font-size:26px;
      font-family:'PingFangSC-Regular';
      color:#0f2d3e;
      line-height:37px;
    }
    //搜索框
    .ivu-input-group .ivu-input{
      height:41px;
      border-radius:0px;
      padding-left:9px;
      border:1px solid rgba(231,231,231,1);
      font-size:14px;
    }
    //搜索框获取焦点
    .ivu-input:focus{
      border:1px solid rgba(231,231,231,1);
      box-shadow: 0 0 0 0 rgba(231,231,231,1);
    }
    //搜索框select
    .ivu-input-group-append{
      background-color:#fff;
      color:#626262;
      border-radius:0;
      padding-top:0;
      padding-bottom:0;
      padding-right:0;
    }
    //搜索框select字体颜色
    .ivu-select-single .ivu-select-selection .ivu-select-placeholder{
      color:#626262;
    }
    //下尖括号
    .ivu-select-arrow{
      color:#626262;
      font-size:16px;
      right:26px;
    }
    //下拉框样式
    .ivu-select-dropdown{
      border-radius: 0;
    }
    .ivu-select-item{
      text-align: left;
    }
    .ivu-select-item:hover{
      color:#00A1FF !important;
    }
    .itemList-searchBox {
      display: flex;
      justify-content: flex-end;
      align-items: flex-start;
      .ivu-input-wrapper  {
        position: static;
        top:0;
      }
    }
    //搜索按钮
    #itemList-searchBtn{
      width:39px;
      height:41px;
      border:none;
      outline:none;
      background:#00A1FF;
      border-bottom:1px solid #00A1FF;
      vertical-align:middle;
      >i{
        color:#fff;
        font-size:30px;
        transform:scale(0.5);
        display:block;
      }
    }
}
</style>

<template>
  <div class="itemList-titleComponent">
    <Row style="margin-top:38px;">
      <i-col span="12" style="text-align:left;">
        <h4 class="itemList-title" v-if="!json">所有项目</h4>
        <h4 class="itemList-title" v-else>{{json}}</h4>
      </i-col>
      <i-col span="12" style="text-align:left;">
        <div class="itemList-searchBox">
          <i-input @input="inputfunc" style="width:569px;" placeholder="搜索" v-model="searchstr" @keyup.enter.native="sendemit">
            <i-select v-model="selectindex" slot="append" style="width: 168px" placeholder="名称和说明">
              <i-option value="1">名称和说明</i-option>
              <i-option value="2">地址</i-option>
            </i-select>
          </i-input>
          <button @click="sendemit" slot="append" id="itemList-searchBtn" @mousedown="btnDown()" @mouseup="btnUp()">
            <i class="font_family icon-icon-test6"></i>
          </button>
        </div>
      </i-col>
    </Row>
  </div>
</template>

<script>
export default {
  props: ['json'],
  data: function () {
    return {
      selectList: [
        {
          value: 0,
          label: '名称和说明'
        },
        {
          value: 1,
          label: '地址'
        },
        {
          value: 2,
          label: '内部ID'
        },
        {
          value: 3,
          label: 'MLS名称'
        },
        {
          value: 4,
          label: 'MLS清单ID'
        }
      ],
      'searchstr': '',
      'selectindex': 1
    }
  },
  methods: {
    btnDown: function () {
      var btn = event.currentTarget
      btn.style.backgroundColor = '#46BBFF'
    },
    btnUp: function () {
      var btn = event.currentTarget
      btn.style.backgroundColor = '#00a1ff'
    },
    sendemit () {
      if (!this.searchstr) {
        this.$Message.error('请输入搜索关键词')
        return false
      }
      this.$emit('childchange', this.searchstr, this.selectindex)
    },
    inputfunc (value) {
      if (value === '') {
        this.$emit('childchange')
      }
    }
  }
}
</script>

<style lang="scss">
.itemList-contentBox{
  cursor: default;
  // max-width:1144px;
  //  margin-top:8px;
  //  覆盖组件card样式
  .ivu-card {
    border-bottom:0;
  }
  .ivu-card-body{
    padding:15px;
  }
}
.itemList-contentBox-inside{
  display:flex;
  min-height:70px;
}
.itemList-thumbnail{
  margin-right:17px;
  width:100px;
  >img{
    display: block;
    width:100px;
    height:70px;
  }
}
//卡片内容样本
@mixin contentCss($h,$fz,$lh){
  min-height:$h;
  font-size:$fz;
  color:rgba(98,98,98,1);
  line-height:$lh;
  text-align:left;
}
.itemList-contentMsg{
  min-height:70px;
  width:876px;
  .itemList-contentMsg-tit{
    @include contentCss(25px,18px,25px);
    font-family:'PingFang-SC';
    color:rgba(98,98,98,1);
  }
  .itemList-contentMsg-address{
    @include contentCss(20px,14px,20px);
    font-family:'PingFangSC';
    color:rgba(98,98,98,1);
  }
  .itemList-contentMsg-source{
    @include contentCss(17px,12px,17px);
    margin-top:6px;
    font-family:'PingFangSC';
    color:rgba(98,98,98,1);
  }
}
.itemList-contentBox-left{
  display:flex;
  width:85%;
}
.itemList-contentFn{
  min-height:70px;
  line-height:70px;
  width:15%;
  min-width:117px;
  position:relative;
}
//卡片功能按键
.itemList-fnbtns{
  list-style:none;
  display:flex;
  width:100%;
  height:28px;
  margin-top:21px;
  justify-content:flex-end;
  align-items: center;
  >li{
    display: flex;
    justify-content: flex-end;
    align-items: center;
    height:28px;
    line-height:28px;
    width:39px;
    text-align:center;
    .ivu-checkbox-wrapper {
      margin-right: 0;
    }
    i {
      font-size:18px;
    }
    .font_family.icon-icon-test11{
      width:39px;
    }
    //功能按钮样式
    .ivu-btn{
      padding:0;
      border:none;
      color:#00A1FF;
      border-radius:0;
      background:#fff;
    }
    .ivu-btn:focus{
      box-shadow:none;
    }
    //复选框样式
    .ivu-checkbox-inner{
      border:2px solid #00A1FF;
      border-radius:0;
    }
    .ivu-checkbox:hover .ivu-checkbox-inner{
      border-color: #00a1ff !important;
    }
    //  弹出框样式
    .ivu-tooltip-popper[x-placement^=bottom] .ivu-tooltip-arrow{
      border-bottom-color: #fff;
    }
    .ivu-tooltip-inner{
      padding:0;
       .ivu-btn{
        display:block;
        width:120px;
        height:36px;
        text-align:left;
        font-size:14px;
        line-height:36px;
        padding-left:8px;
        padding-right:8px;
      }
      .ivu-btn:hover{
        background:rgba(193,193,193,0.4);
      }
    }
  }
  .ivu-tooltip-inner{
    background-color:#fff;
  }
  .itemList-fnbtn-person{
    list-style: none;
    li{
      width:120px;
      height:36px;
      line-height:36px;
    }
  }
  .icon-content{
    color:#00A1FF;
    text-align: center;
    height: 36px;
    width: 80px;
    line-height: 36px;
    font-family: "font_family" !important;
    font-size: 10px;
  }
}

</style>

<template>
  <div class="itemList-contentBox">
    <Card style="min-height:100px;">
      <div class="itemList-contentBox-inside" >
        <div class="itemList-contentBox-left" @click.stop="gotodetilfunc">
          <div class="itemList-thumbnail">
            <img :src="imgsrc" alt="" >
          </div>
          <div class="itemList-contentMsg">
            <p class="itemList-contentMsg-tit">{{json.title}}</p>
            <p class="itemList-contentMsg-address">{{address}}</p>
            <p class="itemList-contentMsg-source">{{desbute}}</p>
          </div>
        </div>
        <div class="itemList-contentFn" v-if="editorShow">
          <ul class="itemList-fnbtns">
            <li @click.stop="personfunc(json)">
              <Tooltip>
                <i-button style="width:39px;height:28px;">
                  <i class="font_family icon-icon-test4" style="13px;"></i>
                </i-button>
                <div slot="content">
                  <div class="icon-content">邀请合作者</div>
                </div>
              </Tooltip>
            </li>
            <li @click.stop="morefunc">
              <Tooltip placement="bottom-end" width="400">
                <i-button style="width:39px;height:28px;">
                  <i class="font_family icon-icon-test11" style="font-size12px;display:block;transform:scale(0.25)"></i>
                </i-button>
                <div slot="content" style="background-color:#fff;" class="api">
                  <Button type="primary" icon="edit" @click.stop="editFile(json)" style="border-bottom: 1px solid #e0e0e0;">
                    编辑文件
                  </Button>
                  <Button type="primary" icon="folder" @click.stop="moveFile(json)">
                    移动到文件夹
                  </Button>
                  <Button type="primary" icon="folder" @click.stop="deleteFile(json)" v-if="showDele">
                    删除空间
                  </Button>
                </div>
              </Tooltip>
            </li>
            <li>
              <Tooltip>
                <Checkbox v-model="isCheck" @click.prevent.native="checkThis(json)"></Checkbox>
                <div slot="content">
                  <div class="icon-content">选择</div>
                </div>
              </Tooltip>
            </li>
          </ul>
        </div>
      </div>
    </Card>
  </div>
</template>

<script>
export default {
  watch: {
    'isCheckAll': function (val) {
      this.isCheck = val
    },
    showEditorChange (newVal) {
      this.showEditor = newVal
    },
    jsonMsg: function (newVal) {
      if (this.$store.state.userInfo.administrator === 2 || newVal.status === 2) {
        this.editorShow = true
      } else {
        this.editorShow = false
      }
    }
  },
  data: function () {
    return {
      isCheck: false,
      showEditor: false,
      editorShow: false,
      showDele: false
    }
  },
  props: ['json', 'checkAll'],
  created () {
    if (this.$store.state.userInfo.administrator === 2) {
      this.editorShow = true
      this.showDele = true
    } else {
      this.editorShow = false
      this.showDele = false
    }
    if (!this.json.status || this.json.status === 2) {
      this.editorShow = true
    } else {
      this.editorShow = false
    }
  },
  computed: {
    jsonMsg () {
      return this.json
    },
    address () {
      return this.json.address + this.json.location
    },
    imgsrc () {
      if (this.json.marker_image) {
        return this.$imgURL + this.json.marker_image
      } else {
        return this.$imgURL + '/assets/img/2.jpg'
      }
    },
    desbute () {
      let arr = this.json.addtime.split('-')
      let time = '2017年10月21日'
      if (arr.length === 3) {
        time = arr[0] + '年' + arr[1] + '月' + arr[2] + '日'
      }
      return '该项目由' + '康云科技' + '创建于' + time
    },
    isCheckAll () {
      return this.$store.state.checkAll
    },
    showEditorChange () {
      return this.$store.state.showEditorTo
    }
  },
  methods: {
    deleteFile (data) {
      this.$store.dispatch('deleteFileSpace', {
        isShow: true,
        json: data
      })
    },
    editFile (data) {
      this.$store.dispatch('showEditorTo', {
        isShow: true,
        json: data
      })
    },
    moveFile (data) {
      this.$store.dispatch('showCreateTo', {
        isShow: true,
        json: data
      })
    },
    checkThis (data) {
      this.isCheck = !this.isCheck
      if (this.isCheck) {
        this.$store.dispatch('checkShow', data.id)
      } else {
        this.$store.dispatch('checkShowSplice', this.$store.state.checkShow.indexOf(data.id))
      }
    },
    changefunc () {
      return false
    },
    personfunc (data) {
      this.$store.dispatch('showModal', {
        isShow: true,
        json: data
      })
    },
    morefunc () {

    },
    gotodetilfunc () {
      this.$router.push({
        path: '/home',
        query: {
          id: this.json.id
        }
      })
    }
  }
}
</script>

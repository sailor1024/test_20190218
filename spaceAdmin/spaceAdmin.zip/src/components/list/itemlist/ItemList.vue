<style lang="scss">
.itemList{
  margin-left: 0;
  @media screen and (min-width: 992px) {
    margin-left: 154px;
    margin-right:174px;
  }
  @media screen and (max-width: 1120px) {
    margin-left: 70px;
    margin-right:70px;
  }
  padding-bottom: 60px;
  &>.itemList-contentBox:nth-last-child(2) {
    .ivu-card {
      border: 1px solid #dddee1;
    }
  }
}
.nosoure{
  width: 300px;
  height: 100px;
  line-height: 100px;
  font-size: 14px;
  text-align: center;
  margin: 0 auto;
}
</style>

<template>
<div class="itemList">
  <item-list-modal v-if="inviteIf" :inviteProject="inviteProject"></item-list-modal>
  <item-list-title @childchange="reloadfunc"></item-list-title>
  <item-list-subtitle v-if="issoure" @childchange="changevalue"></item-list-subtitle>
  <itemListFolder v-for="(json) in CreateFolderMsg" :json="json" :key="json.title"/>
  <!-- 文件夹重命名 -->
  <itemListFolderRename v-if="FolderRenameIf" :FolderRenameMessage="FolderRenameMessage"/>
  <item-list-content v-for="(json, index) in list" :json="json" :key="index"></item-list-content>
  <item-list-page :count="countnum" v-if="issoure" @pagechange="sourechange"></item-list-page>
  <nosoureComponent v-else/>
  <itemListContentEditor v-if="EditorProjectIf" :EditorProject="EditorProject"/>
  <itemListContentCreate v-if="showCreateIf" :EditorCreate="EditorCreate"/>
  <itemListFolderDelete v-if="showDeleteIf"/>
  <itemListdeletaFile v-if="showDeleteFileIf" :showDeleteFileMsg="showDeleteFileMsg"/>
  <itemListModelFolder v-if="showModelFolderInvite" :inviteFolder="showModelFolderInviteJson"/>
  <itemListFolderMove v-if="showFolderMoveIf" :showFolderMoveIfJson="showFolderMoveIfJson"/>
</div>
</template>

<script>
import itemListTitle from './ItemListTitle'
import itemListContent from './ItemListContent'
import itemListPage from './ItemListPage'
import itemListSubtitle from './ItemListSubtitle'
import nosoureComponent from '@/components/common/nosoureComponent'
import itemListModal from './ItemListModal'
import itemListContentEditor from './itemListContentComp/itemListContentEditor'
import itemListContentCreate from './itemListContentComp/itemListContentCreate'
import itemListFolder from './itemListContentComp/itemListFolder'
// 文件夹重命名
import itemListFolderRename from './itemListContentComp/itemListFolderRename'
// 删除文件夹
import itemListFolderDelete from './itemListContentComp/itemListFolderDelete'
import itemListdeletaFile from './itemListContentComp/itemListdeletaFile'
// 文件夹用户邀请
import itemListModelFolder from './itemListContentComp/itemListModelFolder'
import itemListFolderMove from './itemListContentComp/itemListFolderMove'
export default {
  name: 'itemList',
  computed: {
    // 文件夹用户邀请
    ModelFolderInvite: function () {
      return this.$store.state.ModelFolderInvite
    },
    deleteFileSpace: function () {
      return this.$store.state.deleteFileSpace
    },
    isShow: function () {
      return this.$store.state.showModal
    },
    showEditorTo: function () {
      return this.$store.state.showEditorTo
    },
    showCreateTo: function () {
      return this.$store.state.showCreateTo
    },
    // 创建的文件夹信息
    ListerMsgChange: function () {
      return this.$store.state.ListerMsg
    },
    // 文件夹重命名判断
    FolderRenameTo: function () {
      return this.$store.state.FolderRenameTo
    },
    // 文件夹重命名信息
    FolderRenameMsg: function () {
      return this.$store.state.FolderRename
    },
    // 检测文件夹是否被添加
    FolderJudgment: function () {
      return this.$store.state.FolderJudgment
    },
    // 删除文件夹
    deleteFolder: function () {
      return this.$store.state.deleteFolder
    },
    // 文件夹移动
    FolderMove: function () {
      return this.$store.state.FolderMove
    }
  },
  data () {
    return {
      searchText: '',
      list: this.$store.state.Lister,
      type: 2,
      issoure: true,
      asignarr: [],
      checkItems: 0,
      checkAll: false,
      countnum: 0,
      // 邀请用户判断
      inviteIf: false,
      // 邀请用户项目信息
      inviteProject: '',
      // 项目编辑判断
      EditorProjectIf: false,
      // 编辑项目信息
      EditorProject: '',
      // 移动文件夹判断
      showCreateIf: false,
      // 移动文件夹信息
      EditorCreate: '',
      // 文件夹区域信息
      CreateFolderMsg: [],
      // 文件夹重命名
      FolderRenameIf: false,
      // 文件夹重命名信息
      FolderRenameMessage: [],
      // 删除文件夹信息
      showDeleteIf: false,
      showDeleteFileIf: false,
      showDeleteFileMsg: '',
      // 文件夹用户邀请
      showModelFolderInvite: false,
      showModelFolderInviteJson: '',
      // 移动文件夹
      showFolderMoveIf: false,
      showFolderMoveIfJson: ''
    }
  },
  watch: {
    // 文件夹移动
    FolderMove: function (newVal) {
      this.showFolderMoveIf = newVal.isShow
      this.showFolderMoveIfJson = newVal.json
    },
    // 文件夹用户邀请
    ModelFolderInvite: function (newVal) {
      this.showModelFolderInvite = newVal.isShow
      this.showModelFolderInviteJson = newVal.json
    },
    deleteFileSpace: function (newVal) {
      this.showDeleteFileIf = newVal.isShow
      this.showDeleteFileMsg = newVal.json
    },
    // 创建的文件夹信息
    ListerMsgChange: function (newVal) {
      this.CreateFolderMsg.push(newVal)
    },
    // 邀请用户
    isShow: function (newVal) {
      this.inviteIf = newVal.isShow
      this.inviteProject = newVal.json
    },
    // 编辑项目
    showEditorTo: function (newVal) {
      this.EditorProjectIf = newVal.isShow
      this.EditorProject = newVal.json
    },
    // 移动项目
    showCreateTo: function (newVal) {
      this.showCreateIf = newVal.isShow
      this.EditorCreate = newVal.json
    },
    // 文件夹重命名判断
    FolderRenameTo (newVal) {
      this.FolderRenameIf = newVal
    },
    // 文件夹重命名信息
    FolderRenameMsg (newVal) {
      this.FolderRenameMessage = newVal
    },
    // 文件夹是否被添加
    FolderJudgment (newVal) {
      this.GetFolder()
    },
    // 删除文件夹
    deleteFolder (newVal) {
      this.showDeleteIf = newVal
    }
  },
  methods: {
    changevalue (name) {
      this.type = name
      this.loadsoure(this.type)
    },
    sourechange (page) {
      this.loadsoure(this.type, page)
    },
    reloadfunc (search, type) {
      if (search) {
        this.searchfunc(search, type, this.$store.state.userInfo.id)
      } else {
        let arr = this.asignarr
        this.list = arr
      }
    },
    searchfunc (key, type, userid) {
      this.$http.post('/index/index/search', {
        'key': key,
        'userid': this.$store.state.userInfo.id,
        'type': type
      }).then((res) => {
        let data = res.data
        if (data.code === 1) {
          this.list = data.data
        } else {
          this.$Message.warning('没有找到呢')
        }
      }).catch(() => {})
    },
    // 获取项目信息
    loadsoure (type, page = 1) {
      this.$http.post('/index/index/space_list', {
        'userid': this.$store.state.userInfo.id,
        'type': type,
        'page': page,
        'phone': this.$store.state.userInfo.phone
      }).then((res) => {
        let data = res.data
        if (data.code === 1) {
          this.list = data.data.list
          this.asignarr = data.data.list
          this.countnum = data.data.count
        } else {
          this.$Message.error('出错了,请重试')
        }
        if (this.list.length === 0) {
          this.issoure = false
        }
      })
    },
    // 获取文件夹信息
    GetFolder () {
      this.$http.post('index/file/filelist', {
        // 传递用户id
        userId: this.$store.state.userInfo.id,
        phone: this.$store.state.userInfo.phone
      }).then((res) => {
        if (res.data.data.length > 0) {
          this.CreateFolderMsg = res.data.data
          // 记录文件夹目录信息
          this.$store.dispatch('moveFolderProject', res.data.data)
          this.getUserFolder()
        } else {
          this.getUserFolder()
        }
      })
    },
    // 获取邀请的合作者创建的文件夹
    getUserFolder () {
      this.$http.post('index/file/sonfilelist', {
        // 传递用户id
        'id': this.$store.state.userInfo.id
      }).then((res) => {
        // sessionStorage.setItem('projectMsg', JSON.stringify(res.data.data))
        if (res.data.data.length > 0) {
          setTimeout(() => {
            let arr = res.data.data
            for (let i = 0; i < arr.length; i++) {
              this.CreateFolderMsg.push(arr[i])
            }
          }, 100)
          // this.$store.dispatch('moveFolderProject', res.data.data)
        }
      })
    }
  },
  created () {
    this.loadsoure(this.type)
    this.GetFolder()
    this.$http.post('index/index/getuniqueimage', {
      userid: this.$store.state.userInfo.id
    }).then((res) => {})
    // 补充的接口
    this.$http.post('index/file/modelexiste', {
      'userid': this.$store.state.userInfo.id
    }).then((res) => {})
    // 在这里必须进行设置当前文件夹信息为顶层目录
    localStorage.setItem('FolderJsonOnce', JSON.stringify(0))
  },
  destroyed () {
    this.$store.dispatch('showModal', false)
  },
  components: {
    itemListTitle,
    itemListSubtitle,
    itemListContent,
    itemListPage,
    nosoureComponent,
    itemListModal,
    itemListContentEditor,
    itemListContentCreate,
    itemListFolder,
    itemListFolderRename,
    itemListFolderDelete,
    itemListdeletaFile,
    itemListModelFolder,
    itemListFolderMove
  }
}
</script>

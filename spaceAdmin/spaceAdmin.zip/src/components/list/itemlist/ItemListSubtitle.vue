<style lang="scss">
.itemList-subTitle{
  margin-left:15px;
  height:20px;
  line-height:20px;
  >span{
    color:#626262;
    font-size:14px;
    margin-right:4px;
  }
  >.icon-icon-test{
    color:#626262;
    font-size:10px;
  }
}
.itemList-checkAll{
  display:flex;
  align-items: center;
  justify-content: flex-end;
  .move {
    height:100%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    span {
      font-size: 12px;
      color: #626262;
    }
    i {
      color:#00A1FF;
      font-size:18px;
      font-weight: bold;
      padding-left:2px;
    }
  }
  .checkAll {
    height:100%;
    margin-left:10px;
    span:first-child{
      font-size:12px;
      color:#626262;
    }
    .ivu-checkbox-inner{
      border:2px solid #00A1FF;
      border-radius: 0px;
    }
  }
}
.itemList-subTitle{
  .slide {
    border-bottom:1px solid #e0e0e0 !important;
  }
  .slide:last-child {
    border-bottom:0 !important;
  }
  .ivu-checkbox:hover .ivu-checkbox-inner{
    border-color: #00a1ff !important;
  }
  //select
  .ivu-select-single .ivu-select-selection{
    height:20px;
  }
  //select边框，背景
  .ivu-select-selection{
    border:none;
    border-radius: 0px;
    background: transparent;
  }
  //select高度
  .ivu-select-single .ivu-select-selection .ivu-select-placeholder, .ivu-select-single .ivu-select-selection .ivu-select-selected-value{
    height:20px;
    line-height:20px;
  }
  //边框阴影
  .ivu-select-visible .ivu-select-selection{
    box-shadow: 0 0 0 0;
  }
  //下拉框样式
  .ivu-select-dropdown{
    border-radius:0;
  }
  .ivu-select-item:hover{
    color:#00a1ff !important;
  }
  .ivu-select-single .ivu-select-selection .ivu-select-placeholder{
    color:#626262;
  }
}
.itemList-checkAll{
  .ivu-checkbox:hover .ivu-checkbox-inner{
    border-color: #00a1ff !important;
  }
}
#marginChange {
  margin-right:16px;
}
</style>

<template>
<div style="margin-bottom:8px;">
  <itemListContentCreate :checkShowChange="checkShowChange" v-if="moveShow"/>
  <Row style="margin-top:31px;">
    <i-col span="12" style="text-align:left;">
      <div class="itemList-subTitle">
        <i-select @on-change="valuechange" style="width:102px;" placeholder="创建日期">
          <i-option :value="item.value" v-for="(item,index) in selectList" :key="index" class="slide">{{item.label}}</i-option>
        </i-select>
      </div>
    </i-col>
    <i-col span="12" style="text-align:right;">
      <div class="itemList-checkAll">
        <!-- 移动 -->
        <div class="move" v-show="showMove" @click="projectMove">
          <span>移动</span>
          <i class="font_family icon-share"></i>
        </div>
        <!-- 全选 -->
        <div class="checkAll">
          <span>选择所有项目</span>
          <Checkbox id="marginChange" v-model="isCheckAll" @click.prevent.native="checkChange()"></Checkbox>
        </div>
      </div>
    </i-col>
  </Row>
</div>
</template>

<script>
import itemListContentCreate from './itemListContentComp/itemListContentCreate'
export default {
  watch: {
    checkShowChange (newVal) {
      // 选中的项目id数组
      if (newVal.length > 0) {
        this.showMove = true
      } else {
        this.showMove = false
      }
    },
    showMoveCreateTo (newVal) {
      this.moveShow = newVal
    }
  },
  props: ['items'],
  created: function () {
  },
  computed: {
    isCheckAll () {
      return this.$store.state.checkAll
    },
    checkShowChange () {
      return this.$store.state.checkShow
    },
    showMoveCreateTo () {
      return this.$store.state.showMoveCreateTo
    }
  },
  methods: {
    // 多选项目移动
    projectMove: function () {
      this.$store.dispatch('showMoveCreateTo', true)
      this.moveShow = true
    },
    checkChange: function () {
      this.$store.dispatch('checkAll', !this.isCheckAll)
      this.showMove = this.isCheckAll
      let arr = this.$store.state.Lister
      if (this.isCheckAll) {
        for (let i = 0; i < arr.length; i++) {
          this.$store.dispatch('checkShow', arr[i].id)
        }
      } else {
        this.$store.commit('checkShowSpace')
      }
    },
    valuechange (name) {
      this.$emit('childchange', name)
    }
  },
  data: function () {
    return {
      selectList: [
        {
          value: 1,
          label: '名称'
        },
        {
          value: 2,
          label: '创建日期'
        }
        // {
        //   value: 3,
        //   label: '邮政编码'
        // },
        // {
        //   value: 4,
        //   label: '内部ID'
        // },
        // {
        //   value: 5,
        //   label: 'MLS清单ID'
        // },
        // {
        //   value: 5,
        //   label: '修改日期'
        // }
      ],
      showMove: false,
      moveShow: false
    }
  },
  components: {
    itemListContentCreate
  }
}
</script>

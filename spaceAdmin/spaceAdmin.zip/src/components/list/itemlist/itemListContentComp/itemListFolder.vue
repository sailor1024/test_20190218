<template>
  <div class="itemList-contentBox">
    <Card style="min-height:100px;">
      <div class="itemList-contentBox-inside" >
        <div class="itemList-contentBox-left" @click.stop="gotodetilfunc">
          <div class="itemList-thumbnail">
            <img src="../../../../assets/images/project.png" alt="" >
          </div>
          <div class="itemList-contentMsg">
            <p class="itemList-contentMsg-tit">{{json.name}}</p>
            <p class="itemList-contentMsg-address">{{json.projectnumber ? json.projectnumber : 0}} 个项目</p>
            <!-- <p class="itemList-contentMsg-source"></p> -->
          </div>
        </div>
        <div class="itemList-contentFn" v-if="editorShow">
          <ul class="itemList-fnbtns">
            <li>
              <Tooltip>
                <i-button style="width:39px;height:28px;" @click.stop="inviteFolder(json)">
                  <i class="font_family icon-icon-test4" style="13px;"></i>
                </i-button>
                <div slot="content">
                  <div class="icon-content">邀请合作者</div>
                </div>
              </Tooltip>
            </li>
            <li>
              <Tooltip placement="bottom-end" width="400">
                <i-button style="width:39px;height:28px;">
                  <i class="font_family icon-icon-test11" style="font-size12px;display:block;transform:scale(0.25)"></i>
                </i-button>
                <div slot="content" style="background-color:#fff;" class="api">
                  <Button type="primary" icon="edit" style="border-bottom: 1px solid #e0e0e0;" @click="rename(json)">
                    重命名
                  </Button>
                  <Button type="primary" icon="folder" style="border-bottom: 1px solid #e0e0e0;" @click.stop="MoveFolder(json)">
                    移动到文件夹
                  </Button>
                  <Button type="primary" icon="folder" @click.stop="delate(json)" v-if="editorShowDeleFolder">
                    删除文件夹
                  </Button>
                </div>
              </Tooltip>
            </li>
            <li>
              <Tooltip>
                <Checkbox v-model="isCheck" @click.prevent.native="checkThis(json)"></Checkbox>
                <div slot="content">
                  <div class="icon-content">选择</div>
                </div>
              </Tooltip>
            </li>
          </ul>
        </div>
      </div>
    </Card>
  </div>
</template>

<script>
export default {
  props: ['json'],
  data () {
    return {
      isCheck: false,
      editorShow: false,
      editorShowDeleFolder: false,
      // 保存当前的文件夹的id
      FolderId: []
    }
  },
  created () {
    if (this.$store.state.userInfo.administrator === 2) {
      this.editorShow = true
      this.editorShowDeleFolder = true
    } else {
      this.editorShow = false
      this.editorShowDeleFolder = false
    }
    if (!this.json.status) {
      this.editorShow = true
    } else if (this.json.status === 2) {
      this.editorShow = true
    } else {
      this.editorShow = false
    }
  },
  watch: {
    check: function (val) {
      this.isCheck = val
    }
  },
  computed: {
    check () {
      return this.$store.state.checkAll
    }
  },
  methods: {
    // 文件夹邀请
    inviteFolder (data) {
      this.$store.dispatch('ModelFolderInvite', {
        isShow: true,
        json: data
      })
    },
    // 移动文件夹
    MoveFolder (data) {
      this.$store.dispatch('FolderMove', {
        isShow: true,
        json: data
      })
    },
    checkThis (data) {
      this.isCheck = !this.isCheck
      if (this.isCheck) {
        this.$store.dispatch('checkShow', data.id)
      } else {
        this.$store.dispatch('checkShowSplice', this.$store.state.checkShow.indexOf(data.id))
      }
    },
    gotodetilfunc: function () {
      // 使用localStroge存储当前的文件夹信息(很重要，不要删)
      localStorage.setItem('FolderJsonOnce', JSON.stringify(this.json.id))
      // 传参数
      this.$store.dispatch('Folder', this.json)
      // 路由传递数据
      this.$router.push({
        path: '/embed',
        query: {id: this.json.id}
      })
    },
    rename: function (data) {
      this.$store.dispatch('FolderRenameTo', true)
      // 重命名文件夹信息
      this.$store.dispatch('FolderRename', data)
    },
    delate (data) {
      this.$store.dispatch('deleteFolder', true)
      this.$store.dispatch('deleteFolderMsg', data)
    }
  }
}
</script>
<style lang="scss" scoped>
.itemList-contentBox{
  cursor: default;
  // max-width:1144px;
  //  margin-top:8px;
  //  覆盖组件card样式
  .ivu-card {
    border-bottom:0;
  }
  .ivu-card-body{
    padding:15px;
  }
}
.itemList-contentBox-inside{
  display:flex;
  min-height:70px;
}
.itemList-thumbnail{
  margin-right:17px;
  width:100px;
  >img{
    display: block;
    width:100px;
    height:70px;
  }
}
//卡片内容样本
@mixin contentCss($h,$fz,$lh){
  min-height:$h;
  font-size:$fz;
  color:rgba(98,98,98,1);
  line-height:$lh;
  text-align:left;
}
.itemList-contentMsg{
  min-height:70px;
  width:876px;
  .itemList-contentMsg-tit{
    @include contentCss(25px,18px,25px);
    font-family:'PingFang-SC';
    color:rgba(98,98,98,1);
  }
  .itemList-contentMsg-address{
    @include contentCss(20px,14px,20px);
    font-family:'PingFangSC';
    color:rgba(98,98,98,1);
  }
  .itemList-contentMsg-source{
    @include contentCss(17px,12px,17px);
    margin-top:6px;
    font-family:'PingFangSC';
    color:rgba(98,98,98,1);
  }
}
.itemList-contentBox-left{
  display:flex;
  width:85%;
}
.itemList-contentFn{
  min-height:70px;
  line-height:70px;
  width:15%;
  min-width:117px;
  position:relative;
}
//卡片功能按键
.itemList-fnbtns{
  list-style:none;
  display:flex;
  width:100%;
  height:28px;
  margin-top:21px;
  justify-content:flex-end;
  align-items: center;
  >li{
    display: flex;
    justify-content: flex-end;
    align-items: center;
    height:28px;
    line-height:28px;
    width:39px;
    text-align:center;
    .ivu-checkbox-wrapper {
      margin-right: 0;
    }
    i {
      font-size:18px;
    }
    .font_family.icon-icon-test11{
      width:39px;
    }
    //功能按钮样式
    .ivu-btn{
      padding:0;
      border:none;
      color:#00A1FF;
      border-radius:0;
      background:#fff;
    }
    .ivu-btn:focus{
      box-shadow:none;
    }
    //复选框样式
    .ivu-checkbox-inner{
      border:2px solid #00A1FF;
      border-radius:0;
    }
    .ivu-checkbox:hover .ivu-checkbox-inner{
      border-color: #00a1ff !important;
    }
    //  弹出框样式
    .ivu-tooltip-popper[x-placement^=bottom] .ivu-tooltip-arrow{
      border-bottom-color: #fff;
    }
    .ivu-tooltip-inner{
      padding:0;
       .ivu-btn{
        display:block;
        width:120px;
        height:36px;
        text-align:left;
        font-size:14px;
        line-height:36px;
        padding-left:8px;
        padding-right:8px;
      }
      .ivu-btn:hover{
        background:rgba(193,193,193,0.4);
      }
    }
  }
  .ivu-tooltip-inner{
    background-color:#fff;
  }
  .itemList-fnbtn-person{
    list-style: none;
    li{
      width:120px;
      height:36px;
      line-height:36px;
    }
  }
  .icon-content{
    color:#00A1FF;
    text-align: center;
    height: 36px;
    width: 80px;
    line-height: 36px;
    font-family: "font_family" !important;
    font-size: 10px;
  }
}

</style>

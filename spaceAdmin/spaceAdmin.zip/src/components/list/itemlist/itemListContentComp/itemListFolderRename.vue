<template>
<div class="dialog_container">
  <div class="dialog_box">
    <div class="dialog_body">
      <div class="dialog_content">
        <!-- title -->
        <h3 class="dialog_body-title">重命名</h3>
        <!-- detail -->
        <div class="dialog_body-detail">
          <input type="text" v-model="name" placeholder="名字" style="border:0; font-size:14px;" class="create-input" @focus="focus" @keyup="show" @blur="blur">
          <p style="" :class="{'active': active}"></p>
        </div>
      </div>
      <!-- comfrim -->
      <div class="dialog_body-choose">
        <div class="confirm"  @click="yes">确定</div>
        <div class="cancle"  @click="popClose">取消</div>
      </div>
      <!-- close btn-->
      <div class="dialog_body-close" @click="popClose">
        <Icon type="close-round"></Icon>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: 'pop',
  data () {
    return {
      popOff: true,
      active: false,
      name: ''
    }
  },
  created () {
    this.name = this.FolderRenameMessage.name
  },
  props: ['FolderRenameMessage'],
  methods: {
    show (e) {
      if (e.keyCode === 13) {
        this.yes()
      }
    },
    yes: function () {
      this.$Loading.start()
      this.$http.post('index/user/redirname', {
        // 文件夹id
        dirid: this.FolderRenameMessage.id,
        // 传递用户修改的名字
        dirname: this.name
      }).then((res) => {
        this.$Message.success('修改成功')
        this.popClose()
        this.$Loading.finish()
        // 路由刷新
        this.$store.dispatch('FolderJudgment', true)
        // 路由跳转
        this.$router.push({
          path: '/'
        })
      })
    },
    focus: function () {
      this.active = true
    },
    blur: function () {
      this.active = false
    },
    popClose: function () {
      this.$store.dispatch('FolderRenameTo', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.create-input:focus {
  outline-style: none;
}
.dialog_container {
  display: block;
  width: 100%;
  width: 100vw;
  height: 100%;
  height: 100vh;
  background-color: rgba(24,82,94,.7);
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 10;
  .dialog_box {
    display: inline-block;
    border: 1px solid #ccc;
    text-align: left;
    vertical-align: middle;
    position: relative;
    box-shadow: 0 7px 8px -4px rgba(0,0,0,.2), 0 13px 19px 2px rgba(0,0,0,.14), 0 5px 24px 4px rgba(0,0,0,.12);
    .dialog_body {
      position: relative;
      width:18.1vw;
      min-width:258px;
      background-color: #fff;
      .dialog_body-choose {
        display: flex;
        flex-direction: row-reverse;
        justify-content: flex-start;
        align-items: center;
        width:100%;
        padding:20px 18px;
        .confirm {
          padding:10px 40px;
          background: rgb(0, 161, 255);
          color:#fff;
          margin-left:20px;
          cursor: pointer;
        }
        .cancle {
          padding:10px 40px;
          background: #E7E7E8;
          color:#6A6D70;
          cursor: pointer;
        }
      }
      .dialog_content {
        width: 100%;
        background: #fff;
        padding:15px;
        box-sizing: border-box;
        .dialog_body-title {
          width:100%;
          height:auto;
          padding:15px;
          box-sizing: border-box;
          font-size:24px;
          color:#274A4B
        }
        .dialog_body-detail {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          padding:30px 0;
          span {
            font-size:16px;
            color:#737373;
            padding-bottom:20px;
          }
          p {
            font-size:14px;
            color: #a9a9a9;
            line-height: 18px;
            transition: all .3s ease;
            height:1px;
            background:#ddd;
            margin-top:5px;
            &.active {
              background: rgb(0, 161, 255) !important;
            }
          }
        }
      }
      .dialog_body-close {
        position: absolute;
        top:15px;
        right:15px;
        color:#274A4B;
        cursor:pointer;
      }
    }
  }
}
.dialog_container:after {
  display: inline-block;
  content: '';
  width: 0;
  height: 100%;
  vertical-align: middle;
}
</style>

<template>
  <div class="itemList-dialog-container">
    <div class="itemList-dialog-box">
      <div class="itemList-dialog-body">
        <div class="itemList-dialog-content">
          <!-- title -->
          <h3 class="itemList-dialog-body-title">添加合作者到"{{inviteFolder.name}}"</h3>
          <!-- tips -->
          <div class="itemList-dialog-tips">
            <div class="itemList-dialog-tips-icon">
              <Icon type="information-circled"></Icon>
            </div>
            <div class="itemList-dialog-tips-description">
              <span>合作者必须添加到账户协作者页面（并接受邀请），然后才能将其添加到空间或文件夹</span>
              <a href="javascript;" @click.prevent="toUserlist()" style="color:#2D8CF0">查看账户协作者</a>
            </div>
          </div>
          <!-- detail -->
          <div class="itemList-dialog-detail">
            <div class="itemList-dialog-detail-left">
              <div class="itemList-dialog-email">
                <h1>电子邮件地址</h1>
                <p>要为此空间提供私人访问权限，请输入账户协作者的电子邮件地址</p>
                <input v-model="email" type="text" placeholder="Email Address" @keyup="keyup">
              </div>
              <div class="itemList-dialog-accessType">
                <h1>访问类型</h1>
                <div>
                  <RadioGroup v-model="accessType">
                    <Radio label="可以查看"></Radio>
                    <Radio label="可以编辑"></Radio>
                </RadioGroup>
                </div>
              </div>
            </div>
            <div class="itemList-dialog-detail-right">
              <div class="itemList-dialog-partner">
                <h1>目前的合作者</h1>
                <p>要查看这些项目目前与谁共享，请分别选择他们</p>
                <div class="itemList-dialog-shareTo">
                  <div :class="{'itemList-dialog-shareItem':true,'active':activeIndex === index}" v-for="(tmp,index) in dataMsg" :key="index" @click="handleChange(index, tmp)">{{tmp.famailname + tmp.lastname}}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="itemList-dialog-btns">
          <Button style="background:#e1e1e1;color:#626262;width:84px;" size="large" @click.stop="closeModal()">取消</Button>
          <Button style="background:#2D8CF0;color:#fff;width:84px;" size="large" @click.stop="ensure()">确定</Button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['id', 'inviteFolder'],
  data: function () {
    return {
      accessType: '可以查看',
      activeIndex: 0,
      dataMsg: [],
      email: '',
      list: []
    }
  },
  created () {
    // 请求该项目的活性合作者
    this.$http.post('index/index/reception', {
      'userid': this.$store.state.userInfo.id,
      'phone': this.$store.state.userInfo.phone
    }).then((res) => {
      let list = res.data.data
      for (let i = 0; i < list.length; i++) {
        this.$data.list.push(list[i].email)
      }
    })
    this.$http.post('/index/index/userlist', {
      'userid': this.$store.state.userInfo.id,
      'projectid': this.inviteFolder.id
    }).then((res) => {
      let data = res.data
      if (data.code === 1) {
        this.dataMsg = data.data
      }
    }).catch(() => {
    })
  },
  methods: {
    keyup (e) {
      if (e.keyCode === 13) {
        this.ensure()
      }
    },
    handleChange (index, tmp) {
      this.activeIndex = index
      this.email = tmp.email
    },
    closeModal () {
      this.$store.dispatch('ModelFolderInvite', false)
    },
    ensure () {
      if (this.email) {
        let editor = false
        if (this.accessType === '可以编辑') {
          editor = true
        }
        if (this.list.indexOf(this.email) === -1) {
          this.$Message.error('对不起，只能邀请激活的协作者')
          return false
        } else {
          // 文件夹邀请
          this.$http.post('index/file/direuserinvit', {
            'email': this.email,
            'userid': this.$store.state.userInfo.id,
            // 是否可以编辑
            'type': editor,
            // 发送文件夹id
            'dirid': this.inviteFolder.id
          }).then((res) => {
            this.$Message.success('发送成功')
            this.closeModal()
          })
        }
      } else {
        this.$Message.error('请输入邮箱')
      }
    },
    toUserlist () {
      this.$router.push('/userlist')
    }
  }
}
</script>

<style lang="scss">
.itemList-dialog-container{
  display: block;
  width: 100%;
  width: 100vw;
  height: 100%;
  height: 100vh;
  background-color: rgba(24,82,94,.7);
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 10;
  .itemList-dialog-box{
    display: inline-block;
    border: 1px solid #ccc;
    text-align: left;
    vertical-align: middle;
    position: relative;
    box-shadow: 0 7px 8px -4px rgba(0,0,0,.2), 0 13px 19px 2px rgba(0,0,0,.14), 0 5px 24px 4px rgba(0,0,0,.12);
    top:200px;
    .itemList-dialog-body{
      position: relative;
      width:34.7vw;
      min-width:258px;
      background-color: #fff;
      padding:30px 15px 15px 15px;
      // 主要内用
      .itemList-dialog-content{
        width: 100%;
        background: #fff;
        box-sizing: border-box;
        // 主标题
        .itemList-dialog-body-title{
          width:100%;
          height:auto;
          box-sizing: border-box;
          font-size:26px;
          color:#274A4B
        }
        // 提示
        .itemList-dialog-tips{
          display:flex;
          margin-top:16px;
          padding:8px 0;
          background:#e1e1e1;
          .itemList-dialog-tips-icon{
            width:32px;
            text-align:center;
            height:24px;
          }
          .itemList-dialog-tips-description{
            span,a{
              font-size:12px;
              font-weight:700;
            }
            a{
              color:#00B8CD;
            }
          }
        }
        // 邮箱，访问类型，目前合作者等
        .itemList-dialog-detail{
          display:flex;
          padding-top:16px;
          min-height:240px;
          .itemList-dialog-detail-left{
            flex:6;
            overflow: hidden;
            padding-right:12px;
            border-right:1px solid rgba(193, 193, 193, 0.4);
            display:flex;
            flex-direction:column;
            justify-content: space-between;
            .itemList-dialog-email{
              h1{
                font-size:18px;
                font-weight:bold;
                color:#274A4B
              }
              p{
                margin-top:12px;
                font-size:12px;
                line-height:1.5;
              }
              input{
                border:2px solid transparent;
                outline:none;
                margin-top:24px;
                font-size:14px;
                padding-top:3px;
                padding-bottom:3px;
                color:#626262;
                transition:all 0.3s;
                width:100%;
              }
              input:focus{
                border-bottom-color:#00B8CD;
              }
              input::-webkit-input-placeholder{
                color:#c1c1c1;
              }
            }
            .itemList-dialog-accessType{
              margin-bottom:24px;
              h1{
                font-size:18px;
                font-weight:bold;
                color:#274A4B
              }
              >div{
                margin-top:12px;
                font-size:12px;
              }
            }
          }
          .itemList-dialog-detail-right{
            flex:4;
            padding-left:12px;
            overflow: hidden;
            .itemList-dialog-partner{
              h1{
                font-size:18px;
                font-weight:bold;
                color:#274A4B;
              }
              p{
                margin-top:12px;
                font-size:12px;
                margin-bottom:12px;
                line-height:1.5;
              }
              .itemList-dialog-shareTo{
                border:1px solid rgba(193, 193, 193, 0.4);
                height:170px;
                overflow-y:scroll;
                .itemList-dialog-shareItem{
                  height:24px;
                  line-height:24px;
                  max-width:calc(34.7*0.4vw);
                  white-space: nowrap;
                  text-overflow: ellipsis;
                  overflow: hidden;
                  cursor: pointer;
                  padding-left:10px;
                  box-sizing:border-box;
                  &:hover {
                    background-color: rgba(45, 140, 240, .6);
                    color:#fff;
                  }
                }
                .itemList-dialog-shareItem.active{
                  height:24px;
                  background-color: rgb(45, 140, 240);
                  color: #fff;
                }
              }
            }
          }
        }
      }
      .itemList-dialog-btns{
        text-align:right;
        margin-top:12px;
      }
    }
  }
  //覆盖框架按钮样式
  .ivu-btn:focus{
    box-shadow:0 0 0 0 #000;
  }
  .ivu-btn{
    border:none;
  }
  //覆盖框架radio样式
  .ivu-radio-checked:hover .ivu-radio-inner{
    border-color:#2D8CF0;
  }
  .ivu-radio-inner:after{
    background-color:#2D8CF0;
  }
  .ivu-radio-checked .ivu-radio-inner{
    border-color:#2D8CF0;
  }
}
</style>

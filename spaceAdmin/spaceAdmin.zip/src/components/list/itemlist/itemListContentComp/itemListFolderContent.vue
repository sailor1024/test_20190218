<template>
  <div class="folder-Content">
    <itemListTitle :json="title"/>
    <itemListSubtitle />
    <itemListFolder :json="item" v-for="(item) in Folder" :key="item.id"/>
    <ItemListContent v-for="(json, index) in project" :key="index" :json="json"/>
    <itemListContentCreate v-if="showCreateIf" :EditorCreate="EditorCreate"/>
    <itemListContentEditor v-if="EditorProjectIf" :EditorProject="EditorProject"/>
    <itemListdeletaFile v-if="showDeleteFileIf" :showDeleteFileMsg="showDeleteFileMsg"/>
    <item-list-modal v-if="inviteIf" :inviteProject="inviteProject"></item-list-modal>
  </div>
</template>
<script>
import itemListTitle from '../ItemListTitle'
import itemListSubtitle from '../ItemListSubtitle'
// 引入文件夹
import itemListFolder from './itemListFolder'
// 引入项目信息
import ItemListContent from '../ItemListContent'
// 引入移动文件夹
import itemListContentCreate from './itemListContentCreate'
// 编辑项目
import itemListContentEditor from './itemListContentEditor'
// 删除项目
import itemListdeletaFile from './itemListdeletaFile'
// 邀请用户
import itemListModal from '../ItemListModal'
export default {
  data () {
    return {
      // title信息
      title: '',
      // 传递的项目信息
      FolderPop: [],
      // 文件夹信息
      Folder: [],
      // 项目信息
      project: [],
      showCreateIf: false,
      EditorCreate: '',
      // 项目编辑判断
      EditorProjectIf: false,
      // 编辑项目信息
      EditorProject: '',
      showDeleteFileIf: false,
      showDeleteFileMsg: '',
      // 邀请用户判断
      inviteIf: false,
      // 邀请用户项目信息
      inviteProject: ''
    }
  },
  computed: {
    showCreateTo: function () {
      return this.$store.state.showCreateTo
    },
    showEditorTo: function () {
      return this.$store.state.showEditorTo
    },
    deleteFileSpace: function () {
      return this.$store.state.deleteFileSpace
    },
    isShow: function () {
      return this.$store.state.showModal
    }
  },
  watch: {
    // 移动项目
    showCreateTo: function (newVal) {
      this.showCreateIf = newVal.isShow
      this.EditorCreate = newVal.json
    },
    // 编辑项目
    showEditorTo: function (newVal) {
      this.EditorProjectIf = newVal.isShow
      this.EditorProject = newVal.json
    },
    deleteFileSpace: function (newVal) {
      this.showDeleteFileIf = newVal.isShow
      this.showDeleteFileMsg = newVal.json
    },
    // 邀请用户
    isShow: function (newVal) {
      this.inviteIf = newVal.isShow
      this.inviteProject = newVal.json
    }
  },
  created () {
    let json = this.$store.state.Folder
    if (!json.id) {
      this.FolderPop = JSON.parse(sessionStorage.getItem('FolderId'))
    } else {
      this.FolderPop = json
      sessionStorage.setItem('FolderId', JSON.stringify(this.FolderPop))
    }
    this.$data.title = json.name
    this.getProject()
    this.getFolderChilden()
  },
  methods: {
    // 根据当前的文件夹信息，获取对应的项目信息
    getProject: function () {
      this.$http.post('index/file/getproject', {
        // 传递文件夹id, 获取对应的项目信息
        id: this.FolderPop.id,
        userid: this.$store.state.userInfo.id
      }).then((res) => {
        // 返回文件夹中对应的项目信息
        if (res.data.code === 1) {
          let arr = []
          for (let i = 0; i < res.data.data.length; i++) {
            arr.push(res.data.data[i][0])
          }
          this.project = arr
        }
      })
    },
    // 获取当前文件夹中包含的子文件夹信息
    getFolderChilden: function () {
      this.$http.post('index/user/getdirnumber', {
        // 传递文件夹id, 获取对应的子文件夹信息
        'dirid': this.FolderPop.id
      }).then((res) => {
        // 返回当前子文件夹的信息
        for (let i = 0; i < res.data.data.length; i++) {
          this.Folder.push(res.data.data[i][0])
        }
      })
    }
  },
  components: {
    itemListTitle,
    itemListSubtitle,
    itemListFolder,
    ItemListContent,
    itemListContentCreate,
    itemListContentEditor,
    itemListdeletaFile,
    itemListModal
  }
}
</script>
<style lang="scss" scoped>
.folder-Content {
  margin: 0 174px 0 154px;
}
</style>

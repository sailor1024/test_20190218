<template>
  <div class="userMsg">
    <div class="userMsgTitle">
      <h3>{{username}}</h3>
      <p class="userMsg-border">轮廓</p>
    </div>
    <div class="baseMsg userMsgTitle">
      <h3>基本信息</h3>
      <p>这是您可以查看有关用户的基本信息的位置。</p>
    </div>
    <div class="detailMsg">
      <p>创建于：{{timeShow}}</p>
      <div class="name" v-for="(item, index) in nameMsg" :key="index">
        <p class="name-one">{{item.nameTitle}}</p>
        <p class="name-two">{{item.name}}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'userMsg',
  methods: {
    timestr () {
      if (this.time) {
        this.timeShow = new Date(this.time * 1000).toLocaleString()
      } else {
        this.timeShow = '暂无时间信息'
      }
    }
  },
  created () {
    this.$http.post('/index/index/un_userdetil', {
      'id': this.$route.query.id,
      'phone': this.$route.query.phone
    }).then((res) => {
      let data = res.data
      if (data.code === 1) {
        let json = data.data[0]
        this.username = json.lastname + json.famailname
        this.time = json.addtime
        this.timestr()
        if (json.administrator === 2) {
          this.user = '超级管理员'
        } else if (json.administrator === 1) {
          this.user = '管理员'
        } else if (json.type === 2) {
          this.user = '管理员'
        } else if (json.type === 1) {
          this.user = '用户'
        } else {
          this.user = '用户'
        }
        this.nameMsg = [
          {
            nameTitle: '名字',
            name: json.famailname
          },
          {
            nameTitle: '姓',
            name: json.lastname
          },
          {
            nameTitle: '电话',
            name: json.phone
          },
          {
            nameTitle: '电子邮件地址',
            name: json.email
          },
          {
            nameTitle: '账户类型',
            name: this.user
          },
          {
            nameTitle: '默认上传文件夹',
            name: '没有指定上传文件夹'
          }
        ]
      }
    })
  },
  data () {
    return {
      nameMsg: [
        {
          nameTitle: '名字',
          name: '在'
        },
        {
          nameTitle: '姓',
          name: 'Wang'
        },
        {
          nameTitle: '标题',
          name: '空'
        },
        {
          nameTitle: '电话',
          name: '空'
        },
        {
          nameTitle: '电子邮件地址',
          name: 'li.wang817@gmail.com'
        },
        {
          nameTitle: '账户类型',
          name: '用户'
        },
        {
          nameTitle: '默认上传文件夹',
          name: '没有指定上传文件夹'
        }
      ],
      username: '',
      time: 0,
      user: '',
      timeShow: ''
    }
  },
  computed: {
    // timestr () {
    //   if (this.time) {
    //     return new Date(this.time * 1000).toLocaleString()
    //   } else {
    //     return '暂无时间信息'
    //   }
    // }
  }
}
</script>

<style lang="scss" scoped>
.userMsg {
  padding: 0 174px 0 154px;
  height:89.5vh;
  box-sizing: border-box;
  // background: #F2F2F2;
  .userMsgTitle {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top:33px;
    h3 {
      font-size:24px;
      color:#043F5B;
    }
    p {
      font-size:18px;
      color:#043F5B;
      font-weight: 800;
    }
    .userMsg-border {
      margin-right:203px;
    }
  }
  .baseMsg {
    h3 {
      font-size:18px;
    }
    p {
      font-size:12px;
      font-weight: 100;
      color: #838383;
    }
  }
  .detailMsg {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start;
    &>p {
      margin-top:30px;
    }
  }
  .name {
    margin-top:43px;
    .name-one {
      font-size:20px;
      color:#043F5B
    }
    .name-two {
      font-size:14px;
      color: #838383;
      padding-top:5px;
    }
  }
}
</style>

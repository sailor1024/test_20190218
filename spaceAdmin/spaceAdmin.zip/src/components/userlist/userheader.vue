<template>
  <div >
    <header>
      <h4>所有合作者</h4>
    </header>
  </div>
</template>

<script>
export default {
  name: 'userheader'
}
</script>

<style lang="scss" scoped>
header{
  h4{
    margin-top: 40px;
    height:37px;
    font-size:26px;
    font-family:PingFangSC-Regular;
    color:rgba(15,45,62,1);
    line-height:37px;
  }
}
</style>

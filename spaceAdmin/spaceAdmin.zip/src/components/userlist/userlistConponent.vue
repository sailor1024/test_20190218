<template>
  <div class="userlistComp" :class="json === 2 ? '' : 'active'">
    <usermenue />
    <userlistitem v-for="(json, index) in list" :key="index" :json="json" :jsonIf="iconShow"/>
    <userlistActivation v-if="activationIf"/>
    <userlistDelete v-if="deleteIf"/>
    <nosoureComponent v-if="list.length <= 0"/>
  </div>
</template>

<script>
import userlistitem from './userlistitem'
import usermenue from './usermenue'
import userlistActivation from './userlistActivation'
import userlistDelete from './userlistDelete'
// 暂无图片
import nosoureComponent from '@/components/common/nosoureComponent'
export default {
  name: 'userlistConponent',
  props: ['json'],
  data () {
    return {
      'list': [],
      issoure: false,
      activationIf: false,
      deleteIf: false,
      iconShow: 0
    }
  },
  computed: {
    deleteCollaborator: function () {
      return this.$store.state.deleteCollaborator
    },
    userTabsChange: function () {
      return this.$store.state.userTabs
    },
    activationIfChange: function () {
      return this.$store.state.activationIf
    }
  },
  watch: {
    deleteCollaborator (newVal) {
      this.deleteIf = newVal
    },
    userTabsChange (newVal) {
      this.iconShow = parseInt(newVal)
      this.requestDelete(parseInt(newVal))
    },
    activationIfChange (newVal) {
      if (newVal) {
        this.activationIf = true
      } else {
        this.activationIf = false
      }
    }
  },
  created () {
    let key
    if (!sessionStorage.getItem('key')) {
      key = 0
    } else {
      key = sessionStorage.getItem('key')
    }
    this.requestDelete(parseInt(key))
  },
  methods: {
    // 请求协助者数据
    requestUser () {
      this.$http.post('index/index/reception', {
        'userid': this.$store.state.userInfo.id,
        'phone': this.$store.state.userInfo.phone
      }).then((res) => {
        let data = res.data
        if (data !== '') {
          this.list = data.data
          this.$store.dispatch('activeUser', data.data)
        } else {
          this.list = []
        }
        if (this.list.length === 0) this.issoure = true
      }).catch(() => {
      })
    },
    // 请求有待删除者数据
    requestDelete (newVal) {
      if (newVal === 0) {
        // 活性
        this.requestUser()
      } else if (newVal === 1) {
        // 有待
        this.$http.post('/index/user/waitreception', {
          'userid': this.$store.state.userInfo.id
        }).then((res) => {
          this.list = res.data.data
        })
      } else {
        // 删除
        this.$http.post('/index/user/faildelete', {
          'userid': this.$store.state.userInfo.id
        }).then((res) => {
          this.list = res.data.data
        })
      }
    }
  },
  components: {
    userlistitem,
    usermenue,
    userlistActivation,
    userlistDelete,
    nosoureComponent
  }
}
</script>

<style lang="scss" scoped>
.userlistComp{
  margin:0;
  margin-top:10px;
  background: #fff;
  &.active {
    background: transparent
  }
}
</style>

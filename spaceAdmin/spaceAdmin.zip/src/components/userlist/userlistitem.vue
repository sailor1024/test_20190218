<template>
  <li @click.stop="detilfunc">
    <div class="itembox">
      <div class="leftbox">
        <div class="leftcontent">
          <div class="usericon">
            <!-- <img src="https://ss0.baidu.com/73F1bjeh1BF3odCf/it/u=2224926405,2223186990&fm=85&s=3C2357347370739430C914C7030010B8" /> -->
            <i class="font_family icon-icon-test5"></i>
          </div>
        </div>
      </div>
      <div class="rightbox">
        <div>{{json.lastname + json.famailname || json.email}}</div>
        <div>{{json.email || '该用户没有设置邮箱'}}</div>
        <div v-if="json.type === 2 || json.administrator === 2">管理员</div>
        <div v-else>合作者</div>
      </div>
      <!-- icon delete -->
      <div class="rightboxIcon"  v-if="iconShow === 0">
        <i class="font_family icon-weibiaoti544" @click.stop="deleted(json)" style="font-size:20px;color:#d44444" v-if="iconShow === 0 && this.$store.state.userInfo.administrator === 2"></i>
      </div>
      <!-- icon  activation -->
      <div class="rightboxIcon"  v-if="iconShow === 2 && this.$store.state.userInfo.administrator === 2">
        <i class="font_family icon-shuaxin" @click.stop="activation(json.userid)"></i>
      </div>
      <!-- icon  email -->
      <div class="rightboxIcon" v-if="iconShow === 1 && this.$store.state.userInfo.administrator === 2">
        <i class="font_family icon-email"  @click.stop="email(json)"></i>
      </div>
      <!-- icon delete -->
      <div class="rightboxIcon" v-if="iconShow === 1">
        <i class="font_family icon-weibiaoti544"  @click.stop="deleted(json)" style="font-size:20px;color:#495060" v-if="iconShow === 1 && this.$store.state.userInfo.administrator === 2"></i>
      </div>
    </div>
  </li>
</template>

<script>
export default {
  name: 'userlistitem',
  props: ['json', 'jsonIf'],
  data () {
    return {
      iconShow: 0
    }
  },
  watch: {
    jsonIf: function (newVal) {
      this.iconShow = newVal
    }
  },
  created () {
    if (!sessionStorage.getItem('key')) {
      this.iconShow = 0
    } else {
      this.iconShow = parseInt(sessionStorage.getItem('key'))
    }
  },
  methods: {
    detilfunc () {
      this.$router.push({
        path: '/userMsg',
        query: {
          'id': this.json.id,
          'phone': this.json.phone
        }
      })
    },
    activation (data) {
      // 激活协作者
      this.$store.dispatch('activationIf', true)
      // 传递id信息
      this.$store.dispatch('activationMsg', data)
    },
    deleted: function (data) {
      // 删除合作者
      this.$store.dispatch('deleteCollaborator', true)
      this.$store.dispatch('deleteCollaboratorMsg', data)
    },
    email: function (data) {
      // 邀请合作者
      this.$http.post('index/email/invitewaituser', {
        'id': data.id
      }).then((res) => {
        this.$Message.success('邀请成功')
      })
    }
  }
}
</script>

<style lang="scss" scoped>
$liheight:104px;
.itembox{
  height: $liheight;
  display: flex;
  background-color: white;
  border-top: 1px solid #E7E7E7;
  .leftbox{
    width: 148px;
    .leftcontent{
      line-height: $liheight;
      height: $liheight;
      overflow: hidden;
      .usericon{
        // overflow: hidden;
        box-sizing: border-box;
        width: 51px;
        height: 51px;
        margin: 0 auto;
        margin-top: 27px;
        border-radius: 27px;
        display: flex;
        align-items: center;
        justify-content: center;
        i {
          font-size:50px;
        }
        img{
          display: block;
          width: 100%;
          height: 100%;
        }
      }
    }
  }
  .rightbox{
    flex: 1;
    div:nth-of-type(1){
      height:22px;
      font-size:18px;
      font-family:Helvetica;
      color:rgba(15,45,62,1);
      line-height:22px;
      margin-top: 21px;
    }
    div:nth-of-type(2){
      height:20px;
      font-size:14px;
      font-family:PingFangSC-Regular;
      color:rgba(98,98,98,1);
      line-height:20px;
      margin-top: 2px;
    }
    div:nth-of-type(3){
      height:17px;
      font-size:12px;
      font-family:PingFangSC-Regular;
      color:rgba(98,98,98,1);
      line-height: 17px;
      margin-top: 2px;
    }
  }
  .rightboxIcon {
    height:100%;
    display: flex;
    align-items: center;
    padding-right: 10px;
  }
  .rightboxIcon:last-child {
    padding-right: 20PX;
  }
}
</style>

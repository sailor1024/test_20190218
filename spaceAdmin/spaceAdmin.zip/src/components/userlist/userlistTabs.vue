<template>
  <div id="userlistTabs">
    <Tabs class="userTabs" @on-click="click" :value="key">
        <Tab-pane label="活性" key="0" name="0"></Tab-pane>
        <Tab-pane label="有待" key="1" name="1"></Tab-pane>
        <Tab-pane label="删除" key="2" name="2"></Tab-pane>
    </Tabs>
  </div>
</template>

<script>
export default {
  data () {
    return {
      key: 0
    }
  },
  created () {
    let key = sessionStorage.getItem('key')
    this.$data.key = key
  },
  methods: {
    click: function (data) {
      sessionStorage.setItem('key', data)
      this.$store.dispatch('userTabs', data)
    }
  }
}
</script>
<style lang="scss">
#userlistTabs {
  .userTabs {
    .ivu-tabs-bar {
      margin-bottom:0;
    }
    .ivu-tabs-tab {
      font-size: 16px;
      font-family: PingFangSC-Regular;
      color: #0f2d3e;
      font-weight: bold;
    }
    .ivu-tabs-nav .ivu-tabs-tab:hover {
      color: #57a3f3;
    }
    .ivu-tabs-nav .ivu-tabs-tab-active {
      color: #2d8cf0;
    }
  }
}
</style>
<style lang="scss" scoped>
#userlistTabs {
  padding-top:10px;
  width:100%;
  .userTabs {
    background: white;
    .ivu-tabs-bar {
      margin-bottom:0;
    }
  }
}
</style>

<template>
  <div class="userlistbox">
    <div class="userlist" :class="{'active': administrator === 2 ? false : true}">
      <userheader />
      <userlistTabs v-if="administrator === 2 ? true : false"/>
      <userlistConponent :json="administrator"/>
    </div>
    <!-- 引入用户邀请 -->
    <userlistInvite v-if="administrator === 2 ? true : false"/>
  </div>
</template>

<script>
import userheader from './userheader'
import userlistConponent from './userlistConponent'
import userlistInvite from './userlistInvite'
import userlistTabs from './userlistTabs'
export default {
  created () {
    this.$data.administrator = this.$store.state.userInfo.administrator
  },
  data () {
    return {
      administrator: 1
    }
  },
  name: 'userlist',
  components: {
    userheader,
    userlistConponent,
    userlistInvite,
    userlistTabs
  }
}
</script>

<style lang="scss" scoped>
.userlistbox {
  display: flex;
  justify-content: space-between;
}
.userlist{
  margin-left:141px;
  flex: 1;
  &.active {
    margin-right:174px;
  }
}
@media screen and (max-width: 1100px){
  .userlist{
    margin-left:70px;
  }
}
</style>

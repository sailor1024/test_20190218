<template>
  <div class="content">
    <div class="leftcontent">
      <div class="title">最近更新时间：18/05/29</div>
    </div>
    <div class="rightcontent">
      <div class="itembox">
        <div class="item-mark">
          <Icon class="icon clear" type="help-circled" color="#E7E7E7"></Icon>
        </div>
        <div class="item-titbox">
          <div class="itemicon">
            <Icon type="calendar" size="38" color="#626262"></Icon>
          </div>
          <div class="itemtitle">
            <div>浏览</div>
            <div>永久</div>
          </div>
        </div>
        <div class="item-value">
          <div>{{looknum}}</div>
        </div>
      </div>
      <div class="itembox">
        <div class="item-mark">
          <Icon class="icon clear" type="help-circled" color="#E7E7E7"></Icon>
        </div>
        <div class="item-titbox">
          <div class="itemicon">
            <Icon type="connection-bars" size="38" color="#626262"></Icon>
          </div>
          <div class="itemtitle">
            <div>访问</div>
            <div>永久</div>
          </div>
        </div>
        <div class="item-value">
          <div>{{lookplay}}</div>
        </div>
      </div>
      <div class="itembox">
        <div class="item-mark">
          <Icon class="icon clear" type="help-circled" color="#E7E7E7"></Icon>
        </div>
        <div class="item-titbox">
          <div class="itemicon">
            <Icon type="android-people" size="38" color="#626262"></Icon>
          </div>
          <div class="itemtitle">
            <div>特殊访客</div>
            <div>永久</div>
          </div>
        </div>
        <div class="item-value">
          <div>{{lookuser}}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tabfouConponent',
  data () {
    return {
      'looknum': 0,
      'lookuser': 0,
      'lookplay': 0
    }
  },
  created () {
    this.$http.post('/index/index/statistics', {
      'id': this.$route.query.id
    }).then((res) => {
      let data = res.data
      if (data.code === 1) {
        this.looknum = data.data.looknum
        this.lookuser = data.data.lookuser
        this.lookplay = data.data.lookplay
      } else {

      }
    }).catch(() => {
    })
  }
}
</script>

<style lang="scss" scoped>
.content{
  padding: 29px 52px;
  display: flex;
  flex-direction: column;
  height: 80vh;
  background-color: white;
}
.leftcontent{
  margin-right: 25px;
  .title{
    height:20px;
    font-size:14px;
    font-family:PingFangSC-Regular;
    color:rgba(136,136,136,1);
    line-height:20px;
  }
}
.rightcontent{
  margin-top: 30px;
  flex: 1;
  display: flex;
  .itembox:nth-of-type(2){
    margin-left: 24px;
  }
  .itembox:nth-of-type(3){
    margin-left: 24px;
  }
  .itembox{
    flex: 1;
    height: 187px;
    border-radius:10px;
    border:1px solid rgba(231,231,231,1);
    .item-mark{
      height: 30px;
      .icon{
        float: right;
        margin-right: 20px;
        margin-top: 10px;
      }
    }
    .item-titbox{
      padding-left: 30px;
      .itemicon{
        display: inline-block;
        height: 40px;
        vertical-align: top;
      }
      .itemtitle{
        display: inline-block;
        height: 40px;
        margin-left: 10px;
        div:nth-of-type(1){
          height:20px;
          font-size:14px;
          font-family:PingFang-SC-Medium;
          color:rgba(136,136,136,1);
          line-height:20px;
        }
        div:nth-of-type(2){
          height:17px;
          font-size:12px;
          font-family:PingFangSC-Regular;
          color:rgba(169,169,170,1);
          line-height:17px;
        }
      }
    }
    .item-value{
      div{
        font-size: 60px;
        color: #00A1FF;
        height: 100px;
        line-height: 100px;
        text-align: center;
      }
    }
  }
}
@media screen and (max-width: 1100px){
  .content{
    padding: 29px 12px;
    .title{
      width: 100px;
    }
  }
  .rightcontent{
    .itemtitle{
        display: inline-block;
        height: 40px;
        margin-left: 10px;
        div:nth-of-type(1){
          height:20px;
          font-size:14px;
          font-family:PingFang-SC-Medium;
          color:rgba(136,136,136,1);
          line-height:20px;
          // max-width: 30px;
          // overflow: hidden;
        }
        div:nth-of-type(2){
          height:17px;
          font-size:12px;
          font-family:PingFangSC-Regular;
          color:rgba(169,169,170,1);
          line-height:17px;
        }
      }
  }
}
</style>

<template>
  <div id="tabBar">
    <div class="editbtn">
      <a @click="gotofunc" v-if="status === 2 || path === 2">编辑</a>
      <!-- <a @click="gotofunc" v-else-if="status === 1" style="display:none"></a> -->
      <a @click="gotofunc" v-else style="display:none">不行</a>
    </div>
    <Tabs value="" @on-click="selectfunc">
      <TabPane class="tabphone" label="媒体" name="/home">
        <!-- <taboneConponent :json="json"/> -->
      </TabPane>
      <TabPane class="tabphone" label="详细信息" name="/tabtwo">
        <!-- <tabtwoConponent :json="json"/> -->
      </TabPane>
      <TabPane class="tabphone" label="应用" name="/tabthr">
        <!-- <tabthrConponent /> -->
      </TabPane>
      <TabPane class="tabphone" label="数据统计" name="/tabfou">
        <!-- <tabfouConponent /> -->
      </TabPane>
    </Tabs>
    <router-view :json="json"/>
    <editConponent @parentcolsefunc="colsefunc" v-if="isedit" />
  </div>
</template>

<script>

// import taboneConponent from './tabone/taboneConponent'
// import tabthrConponent from './tabthr/tabthrConponent'
// import tabfouConponent from './tabfou/tabfouConponent'
// import tabtwoConponent from './tabtwo/tabtwoConponent'
import editConponent from '@/components/edit/edit'
export default {
  name: 'tabBarConponent',
  props: ['json'],
  data () {
    return {
      isedit: false,
      status: 1,
      path: 2
    }
  },
  created () {
    this.path = 2
  },
  computed: {
    JsonMsg: function () {
      return this.$store.state.json
    },
    pathJson: function () {
      return this.$route.path
    }
  },
  watch: {
    pathJson: function (newVal) {
      if (newVal === '/home') {
        this.path = 2
      } else {
        this.path = 1
      }
    },
    JsonMsg: function (newVal) {
      this.status = newVal.status
    }
  },
  methods: {
    gotofunc () {
      document.body.style.height = '100vh'
      document.body.style['overflow-y'] = 'hidden'
      this.isedit = true
    },
    colsefunc () {
      document.body.style.height = 'unset'
      document.body.style['overflow-y'] = 'auto'
      this.isedit = false
    },
    selectfunc (name) {
      this.$router.push({
        path: name,
        query: {
          id: this.$route.query.id
        }
      })
    }
  },
  components: {
    editConponent
  }
}
</script>

<style lang="scss">
#tabBar{
  position: relative;
  .editbtn{
    display: block;
    position: absolute;
    right: 0;
    top: 0;
    bottom: 0;
    width: 80px;
    height: 37px;
    z-index: 10;
    a{
      cursor: pointer;
      display: block;
      width: 100%;
      height: 32px;
      border-radius: 4px;
      line-height: 32px;
      text-align: center;
      background-color: #5cadff;
      color: white;
      font-size: 14px;
      &:hover{
        background-color: #00A1FF;
        color: white;
      }
    }
  }
  .tabphone{
    background:rgba(255,255,255,1);
    box-shadow:2px 2px 2px 0px rgba(0,0,0,0.1);
  }
  background-color: #F1F1F1;
  .ivu-tabs-bar{
    border-bottom: 3px solid #00A1FF;
    margin-bottom: 0px;
  }
  .ivu-tabs:after{
    display: none;
  }
  .ivu-tabs-ink-bar{
    display: none;
  }
  .ivu-tabs-nav{
    .ivu-tabs-tab{
      min-width: 80px;
    }
    .ivu-tabs-tab-active {
      min-width: 80px;
      text-align: center;
      color: white;
      background-color: #00A1FF;
      border-radius: 10px 10px 0px 0px;
    }
  }

}
</style>

<template>
  <div>
    <videoConponent />
  </div>
</template>

<script>
import videoConponent from './videoVue/video'
export default {
  name: 'videosConponent',
  components: {
    videoConponent
  }
}
</script>

<style lang="scss" scoped>

</style>

<template>
  <div>
   <views-conponent></views-conponent>
  </div>
</template>

<script>
import viewsConponent from './planAndDownload/view'
export default {
  name: 'viewConponent',
  components: {
    viewsConponent
  }
}
</script>

<style lang="scss" scoped>
</style>

<template>
  <div class="box">
    <iframe :src="htmlsrc"></iframe>
  </div>
</template>

<script>
export default {
  name: 'frameConponent',
  props: ['htmlsrc']
}
</script>

<style lang="scss" scoped>
.box{
  position: relative;
  iframe{
    width: 100%;
    height: 100%;
  }
}

</style>

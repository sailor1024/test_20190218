<template>
  <div>
    <!-- 批量操作栏 -->
    <div class="all-control" v-show="this.list.length !== 0">
      <span class="slectednum">已选择 {{num}} 个</span>
      <span class="all-icon">
        <span v-show="this.chooseList.length === 0" class="choose-font">选择</span>
        <span class="icon-sty">
          <span class="all-download" v-show="this.chooseList.length !== 0" @click="forUrl">
             <i class="font_family icon-xiazai" style="font-size: 128%; color: rgb(169, 169, 170)"></i>
          </span>
          <span v-show="this.chooseList.length !== 0">
             <i class="font_family icon-weibiaoti544" style="font-size: 137%; color: rgb(169, 169, 170)" @click.stop="allPop"></i>
          </span>
          <span @click.stop="selectAll">
            <i class="font_family icon-weigouxuan" style="font-size: 133%; color: rgb(169, 169, 170)" v-if="chooseImg === 0"></i>
            <i class="font_family icon-choosehandle" style="font-size: 133%; color: rgb(169, 169, 170)" v-if="chooseImg === 1"></i>
          </span>
        </span>
      </span>
    </div>
    <imgPop v-if="popShow" @clickNone="none" @clickConfirm="popAll" @clickCancel="cancelParent"></imgPop>
    <imgConponent class="inlineblock" />
    <imgitemConponent v-for="(num, index) in list" :key="index" :json="num" class="inlineblock" :chooseImg="chooseImg" ref="child" @deleteFather="deleted" @totalImgParent="totalNum"  @chooseSrc="selectDownload" @cancelSrc="cancelDownload"/>
    <!-- @changeFather="(type) => {
      ((index, type) => {
        changeIt(index, type)
      })(index, type) -->
    <!-- <imgitemConponent v-for="(num, index) in list" :key="index" :json="num" class="inlineblock"/> -->
  </div>
</template>

<script>
import imgConponent from './imgVue/img'
import imgitemConponent from './imgVue/imgitemConponent'
import imgPop from '@/components/content/tabone/view/imgpopConponent.vue'
let _ = require('lodash')
export default {
  props: ['editurl'],
  name: 'imageConponent',
  data () {
    return {
      'list': [],
      'chooseImg': 0,
      'chooseList': [],
      'num': 0,
      popShow: false,
      'srcList': []
    }
  },
  created () {
    this.$http.post('index/index/imglist', {
      'itemid': this.$route.query.id
    }).then((res) => {
      this.list = res.data.data
    })
  },
  watch: {
    chooseList: {
      handler (newChooseList, oldChooseList) {
        this.num = this.chooseList.length
      },
      deep: true
    }
  },
  methods: {
    totalNum (value) {
      var chooseNum = value
      if (chooseNum === 0) {
        this.chooseList.splice(this.chooseList.index, 1)
      } else {
        this.chooseList.push(chooseNum)
      }
      return chooseNum
    },
    deleted (index) {
      this.list.splice(index, 1)
    },
    allPop (index) {
      this.popShow = true
      this.list.splice(index, 1)
    },
    none (data) {
      this.popShow = false
    },
    cancelParent () {
      this.popShow = false
    },
    popAll () {
      this.popShow = false
    },
    download (name, href) {
      // forUrl (this.srcList) {
      //   let imgUrl
      //   for (var i = 0; i < srcList.length; i++) {
      //     imgUrl = srcList.downloadSrc
      //     console.log(imgUrl)
      //     return imgUrl
      //   }
      // }
      var $a = document.createElement('a')
      $a.setAttribute('href', this.imgUrl)
      $a.setAttribute('download', name)
      var evObj = document.createEvent('MouseEvents')
      evObj.initMouseEvent('click', true, true, window, 0, 0, 0, 0, 0, false, false, true, false, 0, null)
      $a.dispatchEvent(evObj)
    },
    forUrl (srcList) {
      let imgUrl
      for (var i = 0; i < srcList.length; i++) {
        // debugger
        imgUrl = srcList.downloadSrc
        return imgUrl
      }
    },
    selectDownload (src, id) {
      var imgSrc = src
      var imgId = id
      this.srcList.push({
        downloadId: imgId,
        downloadSrc: imgSrc
      })
      this.srcList = _.uniq(this.srcList)
    },
    cancelDownload (id) {
      let i = null
      let srcId = id
      this.srcList.forEach(function (value, index) {
        if (value.downloadId === srcId) {
          i = index
        }
        return i
      })
      this.srcList.splice(i, 1)
      return this.srcList
    },
    selectAll () {
      if (this.chooseImg === 0) {
        this.chooseImg = 1
        this.chooseList.length = this.list.length
        this.num = this.chooseList.length
      } else {
        this.chooseImg = 0
        this.num = 0
        this.chooseList = []
      }
    }
  },
  components: {
    imgConponent,
    imgitemConponent,
    imgPop
  }
}
</script>

<style lang="scss" scoped>
.all-control{
  height: 10%;
  width: 100%;
  height: 38px;
  position: relative;
  .slectednum{
    height: 20px;
    width: 50%;
    position: absolute;
    bottom: -3px;
    left: 21px;
    color: rgb(169, 169, 170);
  }
  .all-icon{
    height: 20px;
    width: 50%;
    position: absolute;
    bottom: 0;
    right: -10px;
    .choose-font{
      color: #a9a9aa;
      position: absolute;
      right: 73px;
      top: 3px;
    }
    .icon-sty{
      position: absolute;
      right: 46px;
    }
  }
}
.inlineblock{
  display: inline-block;
  vertical-align: top;
  margin: 13px 0px 0px 21px;
}
</style>

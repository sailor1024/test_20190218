<template>
  <div>
   <downloads-conponent></downloads-conponent>
  </div>
</template>

<script>
import downloadsConponent from './planAndDownload/download'
export default {
  name: 'downloadConponent',
  components: {
    downloadsConponent
  }
}
</script>

<style lang="scss" scoped>
</style>

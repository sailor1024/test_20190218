<template>
  <div>
    <div class="imgbox">
      <div class="imgdiv" :style="imgsrc" @click="openImg">
        <div class="iconimg">
          <!-- 图片未选择为0，图片选中为1 -->
          <div class="imgSlect">
            <div class="imgSlectSon">
              <div class="imgSlectGrandson">
                <i class="font_family icon-weigouxuan" style="font-size: 133%; color: rgb(169, 169, 170)" @click.stop="select" v-if="childChoose === 0" @click="uploadSrc"></i>
                <i class="font_family icon-choosehandle" style="font-size: 133%; color: rgb(169, 169, 170)" @click.stop="select" v-if="childChoose === 1" @click="deleteSrc"></i>
              </div>
            </div>
          </div>
          <div class="rightbox">
            <div class="imgDownloadFather">
              <div class="imgDownload" @click.stop="download('img','this.$imgURL + this.json.src')">
                <i class="font_family icon-xiazai" style="font-size: 128%; color: rgb(169, 169, 170)"></i>
              </div>
            </div>
            <div class="imgRemoveFather">
              <div class="imgRemove" @click.stop="deleteIt">
                <i class="font_family icon-weibiaoti544" style="font-size: 137%; color: rgb(169, 169, 170)"></i>
              </div>
            </div>
          </div>
        </div>
          <!-- <a class="abox"></a> -->
      </div>
      <imgpop v-if="popShow" @clickNone="none" @clickConfirm="popParent" @clickCancel="cancelParent"></imgpop>
    </div>
    <div class="desbutebox">
      <div class="name">{{json.name}}</div>
      <div class="type">FTP</div>
    </div>
    <!-- 遮罩 -->
    <div class="overlay" v-if="showImg === 1">
      <div class="top-close">
        <div class="videoClose" @click="close">
          <i class="font_family icon-guanbi" style="font-size: 150%;"></i>
        </div>
      </div>
      <div class="go-left">
        <div class="back">
          <i class="font_family icon-fanhui" style="font-size: 300%;"></i>
        </div>
      </div>
      <div class="go-right">
        <div class="next">
          <i class="font_family icon-fanhui-copy" style="font-size: 300%;"></i>
        </div>
      </div>
    <!-- 图片弹窗 -->
      <div class="screen" v-if="showImg === 1">
        <img :src="this.$imgURL + this.json.src" alt="img" height="100%" width="100%">
      </div>
      <div class="video-name">{{json.name}}</div>
    </div>
  </div>
</template>

<script>
import imgpop from '@/components/content/tabone/view/imgpopConponent.vue'
export default {
  props: ['json', 'chooseImg'],
  name: 'imgitemConponent',
  components: {
    imgpop
  },
  data () {
    return {
      showImg: 0,
      childChoose: 0,
      choosenStaus: 0,
      popShow: false,
      imgData: this.$imgURL + this.json.src
    }
  },
  computed: {
    imgsrc () {
      if (this.json) {
        return {
          'backgroundImage': 'url(' + this.$imgURL + this.json.src + ')'
        }
      } else {
        return {}
      }
    }
  },
  watch: {
    chooseImg () {
      this.childChoose = this.chooseImg
    }
  },
  methods: {
    select () {
      if (this.childChoose === 0) {
        this.childChoose = 1
        this.choosenStaus = 1
      } else {
        this.childChoose = 0
        this.choosenStaus = 0
      }
      this.$emit('totalImgParent', this.choosenStaus)
    },
    uploadSrc () {
      this.$emit('chooseSrc', this.imgData, this.json.id)
    },
    deleteSrc () {
      this.$emit('cancelSrc', this.json.id)
      console.log('xiaoniu')
    },
    // abc () {
    //   if (this.chooseNum === 0) {
    //     this.chooseImg = 0
    //   } else {
    //     this.chooseImg = 1
    //   }
    // },
    cancelParent () {
      this.popShow = false
    },
    popParent () {
      this.popShow = false
      this.$emit('deleteFather')
    },
    deleteIt () {
      this.$store.dispatch('popTo', false)
      this.popShow = true
    },
    none (data) {
      this.popShow = false
    },
    download (name, href) {
      var $a = document.createElement('a')
      $a.setAttribute('href', this.$imgURL + this.json.src)
      $a.setAttribute('download', name)
      var evObj = document.createEvent('MouseEvents')
      evObj.initMouseEvent('click', true, true, window, 0, 0, 0, 0, 0, false, false, true, false, 0, null)
      $a.dispatchEvent(evObj)
    },
    openImg () {
      this.showImg = 1
    },
    close () {
      this.showImg = 0
    }
  }
}
</script>

<style lang="scss" scoped>
$imageW:166px;
.imgbox{
  width: $imageW;
  height: $imageW;
  .imgdiv{
    width: $imageW;
    height: $imageW;
    overflow: hidden;
    border-radius: 10px;
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    display: flex;
    // background-image: url('https://cdn-1.matterportvr.cn/apifs/models/ds2U37huWxT/images/BKCR9fpLuUW/06.04.2018_17.48.46.jpg?t=2-61eefa2f7a113c688c944aae9a40d330f4361b07-1529062464-1&width=190&height=340&fit=crop&imgopt=1');
    a{
      display: block;
      width: $imageW;
      height: $imageW;
      position: relative;
      z-index: 10;
    }
    a:hover{
      background-color: rgba($color: #626262, $alpha: 0.5);
    }
    .iconimg{
      // width: 100%;
      height: 20%;
      width: 100%;
      position: relative;
      margin-top: 5%;
      .imgSlect{
      height: 100%;
      width: 40%;
      position: absolute;
      left: 5%;
      .imgSlectSon{
        position: relative;
        .imgSlectGrandson{
          position: absolute;
          left: 0%;
        }
      }
      }
      .rightbox{
      height: 100%;
      width: 55%;
      position: absolute;
      left: 40%;
      .imgDownloadFather{
        position: relative;
        .imgDownload{
          position: absolute;
          right: 30%;
        }
       }
       .imgRemoveFather{
        position: relative;
        .imgRemove{
          position: absolute;
          right: 0%;
        }
       }
      }
    }
  }
}

.desbutebox{
    width: 166px;
    height: 40px;
    display: flex;
    .name{
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
      color: #626262;
      line-height: 40px;
      text-indent: 0.5em;
      font-size: 14px;
    }
    .type{
      width: 32px;
      text-align: center;
      background: #4a4a4a;
      color: #fff;
      padding: 2px 6px;
      border-radius: 2px;
      font-size: 10px;
      align-self: center;
      margin-bottom: 3px;
      margin-right: 5px;
      font-weight: 600;
      white-space: nowrap;
    }
  }
.screen {
position: absolute;
top: 20%;
bottom: 20%;
left: 20%;
right: 20%;
}
.overlay {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background: rgba(0,0,0,0.8);
z-index: 200;
.top-close{
height: 5%;
width: 10%;
position: fixed;
top: 3%;
left: 0;
right: 0;
margin-left: auto;
margin-right: auto;
color:#ffffff;
.videoClose{
position: absolute;
top: 15px;
height: 100%;
width: 100%;
text-align: center;
    }
  }
.go-left{
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  margin-top: auto;
  margin-bottom: auto;
  height: 50%;
  width: 8%;
  color: #ffffff;
  .back{
    position: absolute;
    width: 100%;
    text-align: center;
    top: 50%;
    bottom: 0;
    margin-top: -25px;
    }
  }
.go-right{
  position: fixed;
  right: 0;
  top: 0;
  bottom: 0;
  margin-top: auto;
  margin-bottom: auto;
  color: #ffffff;
  height: 50%;
  width: 8%;
  .next{
    position: absolute;
    width: 100%;
    text-align: center;
    top: 50%;
    bottom: 0;
    margin-top: -25px;
    }
  }
.video-name{
  height: 5%;
  width: 10%;
  position: fixed;
  bottom: 10%;
  left: 0;
  right: 0;
  margin-left: auto;
  text-align: center;
  margin-right: auto;
  color: #ffffff;
  }
}
</style>

<style lang="scss">
$theme-color:#00A1FF;
.plan-download{
  width: 14.7%;
  max-width:302px;
  margin-left:91px;
  @media(max-width:992px){
    margin-left:3%;
  }
  //样本示意图
  .plan-download-img{
    width:100%;
    max-height:227px;
    >img{
      width:100%;
      height:100%;
    }
  }
  //样本示意图下载
  .plan-download-link{
    text-align: center;
    margin-top:15px;
    height:15px;
    line-height:15px;
    cursor:pointer;
    >.plan-down-link-text{
      font-size:12px;
      color:$theme-color;
    }
    >i{
      font-size:15px;
      color:$theme-color;
    }
  }
}
</style>

<template>
  <div class="plan-download">
    <div class="plan-download-img">
      <img src="@/assets/images/example.jpg" alt="">
    </div>
    <div class="plan-download-link">
      <i class="font_family icon-icon-test21"></i>
      <span class="plan-down-link-text">下载样本视图</span>
    </div>
  </div>
</template>

<script>
export default {}
</script>

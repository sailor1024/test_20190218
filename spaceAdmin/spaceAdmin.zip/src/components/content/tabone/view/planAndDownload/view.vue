<style lang="scss">
//字体
$ff:"PingFangSC";
.plan{
  max-width:1540px;
  min-height:935px;
  padding-top:32px;
  font-family:$ff;
}
.plan-detail{
  margin-top:26px;
  display:flex;
}
</style>

<template>
  <div class="plan">
    <buy-comp></buy-comp>
    <div class="plan-detail">
      <img-comp></img-comp>
      <fifth-page></fifth-page>
    </div>
  </div>
</template>

<script>
import buyComp from './commonComp/buyComp'
import imgComp from './commonComp/imgComp'
import fifthPage from './fifthPageComp/fifthPageDesc'
export default {
  name: 'planAndDownload',
  components: {
    buyComp,
    imgComp,
    fifthPage
  }
}
</script>

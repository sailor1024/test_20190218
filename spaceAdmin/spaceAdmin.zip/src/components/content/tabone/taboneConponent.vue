<template>
  <div class="tabone" >
    <lefttabConponent />
    <router-view :htmlsrc="htmlsrc"  class="view"/>
  </div>
</template>

<script>
import lefttabConponent from './lefttabConponent'
export default {
  name: 'taboneConponent',
  props: ['json'],
  computed: {
    htmlsrc () {
      if (this.json.url) {
        return this.$imgURL + this.json.url
      }
    }
  },
  components: {
    lefttabConponent
  }
}
</script>

<style lang="scss" scoped>
.tabone{
  width: 100%;
  height: 100vh;
  box-shadow:1px 1px 2px 1px rgba(0,0,0,0.1);
  display: flex;
  background-color: white;
  .view{
    flex: 1;
  }
}
</style>

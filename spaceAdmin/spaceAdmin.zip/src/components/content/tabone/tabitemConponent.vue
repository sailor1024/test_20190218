<template>
  <div @click="childchange" class="tabitem" :class="this.json.isselect?'active':''">
    <div class="icon">
      <Icon :type="type" size="23" color="#A9A9AA"></Icon>
    </div>
    <div class="fonttitle">{{this.json.name}}</div>
  </div>
</template>

<script>
export default {
  name: 'tabitemConponent',
  props: ['json'],
  methods: {
    childchange () {
      this.$emit('childchange', this.json)
    }
  },
  computed: {
    type: function () {
      return this.json.icon
    }
  }
}
</script>

<style lang="scss" scoped>
.tabitem{
  cursor: pointer;
  width: 80px;
  height: 73px;
  overflow: hidden;
  .icon{
    text-align: center;
    margin-top: 14px;
  }
  .fonttitle{
    margin-top: 4px;
    font-size:10px;
    font-family:PingFangSC-Regular;
    color:#A9A9AA;
    text-align: center;
  }
}
.active{
  position: relative;
  &::after{
    position: absolute;
    display: block;
    content: '123123 ';
    width: 3px;
    height: 78px;
    background-color: #00A1FF;
    top: 0;
    right: 0;
    bottom: 0;
  }
}
</style>

<template>
  <div id="">
  </div>
</template>

<script>
export default {
  name: 'asideConponent'
}
</script>

<style lang="scss" scoped>

</style>

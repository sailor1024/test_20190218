<template>
  <div class="content">
    <div class="submitbox">
      <a @click="savefunc">保存</a>
    </div>
    <div class="contentitem">
      <div class="headeritem">
        <h4>公共信息</h4>
        <p>根据您在工作台中的可见性设置，您填写的信</p>
      </div>
    </div>
    <div class="contentitem">
      <div class="namebox">
        <div class="lablename">项目名称</div>
        <input placeholder="1-1" v-model="titlestr"/>
      </div>
    </div>
    <div class="contentitem">
      <div class="weburlbox">
        <div class="lablename">外部网站地址</div>
        <input placeholder="输入网址以便于在3D展示中展示项目" v-model="modelurl"/>
        <p>例如：https://examplewesite.com/homes/1a2b3c</p>
      </div>
    </div>
    <div class="contentitem">
      <div class="namebox">
        <div class="lablename">联系人姓名</div>
        <input placeholder="康云科技" v-model="niname"/>
      </div>
    </div>
    <div class="contentitem">
      <div class="namebox">
        <div class="lablename">简介</div>
        <input class="longinput" placeholder="填写关于项目的简要介绍" v-model="description"/>
      </div>
    </div>
    <div class="contentitem">
      <div class="namebox">
        <h4 class="lablename addlable">地址</h4>
        <p>请输入项目的完整地址。您可以通过以下选项限制公众对地址的可见性。</p>
      </div>
    </div>
    <div class="contentitem">
      <div class="namebox">
        <div class="lablename">具体地址</div>
        <input class="longinput" placeholder="中华人名共和国广东省广州市黄埔区合景科汇金谷四街1号8楼" v-model="location"/>
      </div>
    </div>
    <div class="addressboxset">
      <div class="lable">地址的可见性设置</div>
      <div>
        <RadioGroup v-model="select">
          <Radio label="1" class="radio" style="margin-top:10px;">
            <span>所有地址信息全部可见</span>
          </Radio>
          <Radio label="2" class="radio">
            <span>仅国家，城市，邮编可见</span>
          </Radio>
          <Radio label="3" class="radio">
            <span>均不可见</span>
          </Radio>
        </RadioGroup>
      </div>
    </div>

    <div class="seinfo">
      <div class="setitlebox">
        <h4>内部信息</h4>
        <p>在3D展示中其他用户仅能看到您所公开的部分，无法查看您的内部隐藏信息。</p>
      </div>
      <div class="timeinfo">
        <div class="timebox">
          <div class="timeitem">
            <span>创建日期</span>
            <span>{{cteateTime}}</span>
          </div>
          <div class="timeitem">
            <span>创建人</span>
            <span>{{this.$store.state.json.niname}}</span>
            </div>
          <div class="timeitem">
            <span>上次操作日期</span>
            <span>{{updateTime}}</span>
            </div>
          <div class="timeitem">
            <span>上次操作人</span>
            <span>{{this.$store.state.json.niname}}</span>
          </div>
        </div>
      </div>
      <div class="inputbox">
        <div class="boxitem">
          <div><input placeholder="内部 ID" v-model="this.$store.state.json.id"/></div>
          <div><input placeholder="LM 清单ID"/></div>
        </div>
        <div class="boxitem">
          <div><input placeholder="LM 名称"/></div>
          <div><input placeholder="描述"/></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tabtwoConponent',
  data () {
    return {
      select: '1',
      titlestr: this.$store.state.json.title,
      description: this.$store.state.json.description,
      location: this.$store.state.json.location,
      niname: this.$store.state.json.niname,
      modelurl: this.$store.state.json.url,
      cteateTime: this.fromat(this.$store.state.json.create_time),
      updateTime: this.fromat(this.$store.state.json.update_time),
      priid: this.$store.state.json.id
    }
  },
  created () {
    this.titlestr = this.$store.state.json.title
    this.description = this.$store.state.json.description
    this.location = this.$store.state.json.location
    this.niname = ''
    this.modelurl = ''
    this.cteateTime = this.fromat(this.$store.state.json.create_time)
    this.updateTime = this.fromat(this.$store.state.json.update_time)
    this.priid = this.$store.state.json.id
  },
  methods: {
    savefunc () {
      this.$http.post('/index/index/save_detil', {
        'title': this.titlestr,
        'url': this.modelurl,
        'description': this.description,
        'location': this.location,
        'id': this.priid
      }).then((res) => {
        let data = res.data
        if (data.code) {
          this.$Message.success('修改成功')
          this.soureupdate()
        } else {
          this.$Message.error('失败了,请重试')
        }
      }).catch(() => {
      })
    },
    soureupdate () {
      let obj = this.$store.state.json
      obj.title = this.titlestr
      obj.url = this.url
      obj.description = this.description
      obj.location = this.location
      this.$store.dispatch('json', obj)
    },
    fromat (time) {
      let date = new Date(time * 1000)
      let y = date.getFullYear() + ''
      let m = date.getMonth() + 1
      let d = date.getDate()
      m = m > 10 ? m : '0' + m
      d = d > 10 ? d : '0' + d
      y = y.slice(2)
      return y + '/' + m + '/' + d
    }
  }
}
</script>

<style lang="scss" scoped>
.content{
  padding: 43px 57px;
  position: relative;
  background-color: white;
}
$abuttonH: 45px;
.submitbox{
  position: absolute;
  top: 26px;
  right: 1.5%;
  width:133px;
  height: $abuttonH;
  background:linear-gradient(180deg,rgba(70,187,255,1),rgba(0,161,255,1));
  border-radius:25px;
  a{
    display: block;
    height: $abuttonH;
    width: 133px;
    line-height: $abuttonH;
    text-align: center;
    color: white;
  }
}
.headeritem{
  h4{
    height:22px;
    font-size:16px;
    font-family:PingFang-SC-Medium;
    color:rgba(32,32,32,1);
    line-height:22px;
  }
  p{
    height:17px;
    font-size:12px;
    font-family:PingFangSC-Regular;
    color:rgba(169,169,170,1);
    line-height:17px;
    margin-top: 8px;
  }
}
.namebox{
  margin-top: 25px;
  .lablename{
    height:17px;
    font-size:12px;
    font-family:PingFangSC-Regular;
    color:rgba(169,169,170,1);
    line-height:17px;
  }
  .addlable{
    width:320px;
    height:22px;
    font-size:16px;
    font-family:PingFang-SC-Medium;
    color:rgba(32,32,32,1);
    line-height:22px;
  }
  input{
    margin-top: 9px;
    height: 20px;
    line-height: 20px;
    font-size: 17px;
    outline: none;
    border: none;
    display: block;
    width: 578px;
    font-size:14px;
    font-family:PingFangSC-Regular;
    border-bottom: 1px solid rgba(231,231,231,1);
  }
  p{
    height:17px;
    font-size:12px;
    font-family:PingFangSC-Regular;
    color:rgba(169,169,170,1);
    line-height:17px;
    margin-top: 8px;
  }
  .longinput{
    border-bottom: 1px solid rgba(231,231,231,1);
    width: 100%;
  }
}
.weburlbox{
   margin-top: 25px;
  .lablename{
    height:17px;
    font-size:12px;
    font-family:PingFangSC-Regular;
    color:rgba(169,169,170,1);
    line-height:17px;
  }
  input{
    margin-top: 9px;
    height: 20px;
    line-height: 20px;
    font-size: 17px;
    outline: none;
    border: none;
    display: block;
    width: 578px;
    font-size:14px;
    font-family:PingFangSC-Regular;
    // color:rgba(229,229,229,1);
    border-bottom: 1px solid rgba(231,231,231,1);
  }
  p{
    margin-top: 5px;
    width:277px;
    height:17px;
    font-size:12px;
    font-family:PingFangSC-Regular;
    color:rgba(136,136,136,1);
    line-height:17px;
  }
}
.addressboxset{
  margin-top: 40px;
  .lable{
    width:96px;
    height:17px;
    font-size:12px;
    font-family:PingFangSC-Regular;
    color:rgba(169,169,170,1);
    line-height:17px;
  }
  .radio{
    margin-bottom: 54px;
    display: block;
  }
}
//内部信息
.seinfo{
  .setitlebox{
    h4{
      // width:64px;
      height:22px;
      font-size:16px;
      font-family:PingFang-SC-Medium;
      color:rgba(32,32,32,1);
      line-height:22px;
    }
    p{
      width:412px;
      height:17px;
      font-size:12px;
      font-family:PingFangSC-Regular;
      color:rgba(169,169,170,1);
      line-height:17px;
      margin-top: 6px;
    }
  }
  .timeinfo{
    margin-top: 23px;
    .timebox{
      display: flex;
      padding-right: 100px;
      .timeitem{
        flex: 1;
        span{
          display: block;
        }
        span:nth-of-type(1){
          height:17px;
          font-size:12px;
          font-family:PingFangSC-Regular;
          color:rgba(169,169,170,1);
          line-height:17px;
        }
        span:nth-of-type(2){
          margin-top: 8px;
          height:17px;
          font-size:14px;
          font-family:Helvetica-Bold;
          color:rgba(95,95,95,1);
          line-height:17px;
        }
      }
    }
  }
  .inputbox{
    width: 100%;
    .boxitem{
      display: flex;
      div{
        flex: 1;
        margin-left: 70px;
        input{
          height: 20px;
          line-height: 20px;
          font-size: 17px;
          outline: none;
          border: none;
          display: block;
          width:100%;
          // width: 578px;
          font-size:14px;
          font-family:PingFangSC-Regular;
          // color:rgba(229,229,229,1);
          border-bottom: 1px solid rgba(231,231,231,1);
          margin-top: 47px;
        }
      }
      div:nth-child(2n+1) {
        margin-left:0;
      }
    }
  }
}
</style>

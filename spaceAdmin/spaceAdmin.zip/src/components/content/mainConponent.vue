<template>
  <div id="main">
    <div id="content">
      <tabBarConponent :json="json"/>
    </div>
  </div>
</template>

<script>
import tabBarConponent from './tabbarConponent'
export default {
  name: 'mainConponent',
  props: ['json'],
  components: {
    tabBarConponent
  }
}
</script>

<style lang="scss" scoped>
#main{
  width: 100%;
  padding: 30px 160px 48px 143px;
  background-color: #F1F1F1;
  #content{
    // height: 933px;
    background-color: white;
  }
}
</style>

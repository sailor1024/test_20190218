<template>
  <div id="home">
    <Header class="header" :title="titlestr"></Header>
    <mainConponent class="maincontent" :json="json"></mainConponent>
  </div>
</template>

<script>
import Header from './common/header/header'
import mainConponent from './content/mainConponent'
export default {
  name: 'Home',
  data () {
    return {
      value: '',
      json: {}
    }
  },
  computed: {
    titlestr () {
      if (this.json.title) {
        return {
          title: this.json.title,
          id: this.json.id
        }
      }
      return ''
    }
  },
  created () {
    this.$http.post('index/index/space_detil', {
      'id': this.$route.query.id,
      'userid': this.$store.state.userInfo.id
    }).then((res) => {
      let data = res.data
      if (data.code === 1) {
        this.json = data.data
        this.$store.dispatch('json', this.json)
        sessionStorage.setItem('jsonMsg', JSON.stringify(this.json))
        this.getModelJson(this.json.dirname)
        let itemid = this.$route.query.id
        let editurl = this.$imgURL + this.json.edit_url + '&tn=' + this.json.dirname + '&itemid=' + itemid + '&t=' + new Date().getTime()
        localStorage.setItem('editurl', editurl)
      } else {
        this.$message.error('出错了,请重试')
      }
    })
  },
  methods: {
    getModelJson: function (data) {
      // 请求判断
      let url = 'https://todo.kangyun3d.cn/assets/museum/01/' + data + '/model.json'
      this.$http.get(url).then((res) => {
        // success
      }).catch((error) => {
        console.log(error)
        this.postCopyJson(data)
        return false
      })
    },
    postCopyJson: function (data) {
      this.$http.get('https://todo.kangyun3d.cn/index.php/index/upload/start_copy?dirname=' + data + '', {
      }).then((res) => {
        // success
      })
    }
  },
  components: {
    Header,
    mainConponent
  }
}
</script>

<style lang="scss" scoped>
</style>

<template>
  <div >
    <pop v-if="popTo" :giveData="title" :shareShow="shareShow"></pop>
    <share v-if="shareTo"></share>
    <Row class="Yun-nav" type="flex">
      <Row class="Yun-nav-container" type="flex" :style="windowReide">
        <i-col span="6" order="1">
          <p class="Yun-space" @click="home">云空间</p>
          <p class="Yun-page">{{title.title}}</p>
        </i-col>
        <!-- <i-col span="10" order="2" v-if="true"></i-col> -->
        <i-col span="18" order="3">
          <div class="Yun-shareSpace">
             <Row :gutter="50">
                <i-col span="6" class="Yun-space-Pos">
                    <div class="Yun-space-list">
                      <i class="font_family icon-icon-test10" @click.stop="popShowHover"></i>
                      <span @click.stop="popShowHover">邀请</span>
                    </div>
                    <!-- 弹出框 -->
                    <div class="Yun-space-pop" v-if="popShow" @click.stop="stop">
                      <form action="1.php" method="post">
                        <div class="Yun-space-pop-header">
                          <div>
                            <Icon class="font_family icon-email"></Icon>
                            <div class="Yun-space-pop-input">
                              <i-input placeholder="请输入邮箱地址" value.sync="value" v-model="email"></i-input>
                            </div>
                            <Dropdown @on-click="selectfunc">
                              <a href="javascript:void(0)">
                                {{canView}}
                                <Icon type="arrow-down-b"></Icon>
                              </a>
                              <Dropdown-menu slot="list" class="yun-space-hover">
                                <Dropdown-item name="可以查看" key="canView">可以查看</Dropdown-item>
                                <Dropdown-item name="可以编辑" key="canEdit">可以编辑</Dropdown-item>
                              </Dropdown-menu>
                            </Dropdown>
                          </div>
                        </div>
                        <div class="inner" v-for="item in data" :key='item'>
                          <Icon class="font_family icon-icon-test5"></Icon>
                          <div class="Yun-space-intived">
                            <div class="invite-name">{{item.lastname}}{{item.famailname}}</div>
                            <div class="invite-email">{{item.email}}</div>
                          </div>
                          <div class="font-box">
                            <div v-if="item.status === 2" class="font-sty">可以编辑</div>
                            <div v-else class="font-sty">可以查看</div>
                          </div>
                        </div>
                        <div class="Yun-space-invite">
                          <i-button @click="sendemail" type="ghost" shape="circle">邀请</i-button>
                        </div>
                      </form>
                    </div>
                </i-col>
                <i-col span="6" style="padding:0;width:94px;">
                    <div class="Yun-space-list" @click="pop">
                      <!-- 可以查看，项目私密-->
                      <i class="font_family icon-icon-test8" style="color:#a9a9a9" v-if="shareShow === 0 && status === 1"></i>
                      <!-- 可以查看，项目公开 -->
                      <i class="font_family icon-icon-test8" style="color:#a9a9a9" v-else-if="shareShow === 1 && status === 1"></i>
                      <!-- 可以编辑，项目私密 -->
                      <i class="font_family icon-icon-test8" v-else-if="shareShow === 0 && status === 2"></i>
                      <!-- 超级管理员显示 -->
                      <i class="font_family icon-icon-test8"  v-else-if="shareShow === 0"></i>
                      <Icon type="unlocked" v-else></Icon>
                      <span v-if="shareShow === 0" style="white-space:nowrap">空间是私人的</span>
                      <span v-else>空间是公共的</span>
                    </div>
                </i-col>
                <i-col span="6">
                    <div class="Yun-space-list" @click="share">
                      <i class="font_family icon-icon-test14" :class="[shareShow === 0 ? 'shareActive' : '']"></i>
                      <span :class="[shareShow === 0 ? 'shareActive' : '']">分享</span>
                    </div>
                </i-col>
                <i-col span="6" class="Yun-space-More-pop">
                    <div class="Yun-space-list">
                      <i class="font_family icon-icon-test11-copy"></i>
                      <span>更多</span>
                    </div>
                    <!-- 弹出框 -->
                    <div class="More-pop">
                      <p>no more</p>
                    </div>
                    <!-- 弹出框 -->
                    <div class="More-pop">
                      <p>no more</p>
                    </div>
                </i-col>
            </Row>
          </div>
        </i-col>
      </Row>
    </Row>
  </div>
</template>

<script>
import pop from '@/components/common/header/headComp/pop'
import share from '@/components/common/header/headComp/share'
export default {
  name: 'clounnavConponent',
  props: ['title'],
  data () {
    return {
      popTo: this.$store.state.popTo,
      shareTo: this.$store.state.shareTo,
      windowReide: this.$store.state.spaceReside,
      canView: '可以查看',
      email: '',
      // 弹出框显示
      popShow: false,
      // 等于0 ==> 私密链接  1 ==> 公开链接
      shareShow: 0,
      // status 1=>可以查看 2=>可以编辑
      status: '',
      editor: false,
      // 活性协作者
      list: [],
      data: []
    }
  },
  components: {
    pop,
    share
  },
  created () {
    // 检测首次是否ipad端
    if (window.innerWidth === 768) {
      this.$data.windowReide = {
        padding: '0 100px'
      }
    }
    // 请求该项目的活性合作者
    this.$http.post('index/index/reception', {
      'userid': this.$store.state.userInfo.id,
      'phone': this.$store.state.userInfo.phone
    }).then((res) => {
      let list = res.data.data
      for (let i = 0; i < list.length; i++) {
        this.list.push(list[i].email)
      }
    })
    this.$http.post('index/index/userlist', {
      'userid': this.$store.state.userInfo.id,
      'projectid': this.$route.query.id
    }).then((res) => {
      let data = res.data
      console.log(data)
      if (data.code === 1) {
        this.data = data.data
      }
    }).catch(() => {
    })
  },
  methods: {
    home: function () {
      this.$router.push({
        path: '/'
      })
    },
    stop: function () {},
    popShowHover () {
      this.popShow = !this.popShow
      document.onclick = () => {
        this.popShow = false
      }
    },
    sendemail () {
      if (this.email) {
        this.editor = false
        if (this.canView === '可以编辑') {
          this.editor = true
        }
        if (this.list.indexOf(this.email) === -1) {
          this.$Message.error('对不起，只能邀请激活的协作者')
          return false
        }
        this.$http.post('/index/email/email', {
          'email': this.email,
          'userid': this.$store.state.userInfo.id,
          'type': this.editor,
          'itemid': this.$route.query.id
        }).then((res) => {
          this.$Message.success('发送成功')
        })
      } else {
        this.$Message.error('请输入邮箱')
      }
    },
    pop: function () {
      if (this.status === 1) {
        this.$Message.error('对不起，您不能公开此项目')
        return false
      }
      if (this.shareShow === 0) {
        this.$data.popTo = true
        this.$store.state.popTo = true
      } else {
        this.popTo = true
        this.$store.state.popTo = true
      }
    },
    share: function () {
      if (this.shareShow) {
        this.$store.state.shareTo = true
        this.$data.shareTo = true
      }
    },
    selectfunc: function (name) {
      this.canView = name
    }
  },
  computed: {
    // 监听vuex中的popTo数据
    popToChange () {
      return this.$store.state.popTo
    },
    shareToChange () {
      return this.$store.state.shareTo
    },
    spaceReside () {
      return this.$store.state.spaceReside
    },
    json () {
      return this.$store.state.json.isshow_offica
    },
    shareShowChange () {
      return this.$store.state.shareShowChange
    },
    JsonMsg () {
      return this.$store.state.json
    }
  },
  watch: {
    json (newVal) {
      this.shareShow = newVal
    },
    popToChange (newVal, oldVal) {
      this.$data.popTo = newVal
    },
    shareToChange (newVal, oldVal) {
      this.$data.shareTo = newVal
    },
    spaceReside (newVal, oldVal) {
      this.$data.windowReide = newVal
    },
    shareShowChange (newVal) {
      this.shareShow = newVal
    },
    JsonMsg (newVal) {
      this.status = newVal.status
    }
  }
}
</script>

<style lang="scss" scoped>
.shareActive {
  color:#a9a9a9 !important;
}
 .layout{
        border: 1px solid #d7dde4;
        background: #00A1FF;
    }
    .layout-logo{
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-end;
        width:129px;
        height:100%;
        .layout-logo-container {
          margin-top:19px;
          img {
            display: block;
            width:129px;
            height:15px;
          }
        }
        .KY-logo {
          width:129px;
          height:15px;
          display: block;
          background: #fff;
          color:#333;
        }
        span {
          font-size:12px;
          font-family: PingFangSC;
          font-weight:Regular;
          line-height:17px;
          color:rgba(255,255,255,1);
        }
    }
    .layout-nav{
      flex:1;
      justify-content: flex-start;
      margin-left:49px;
        li>i {
          width:21px;
          height:24px;
          font-size:20px;
          color:#fff;
        }
    }
    .container {
      width:100%;
      height:100%;
      padding:0 143px;
      display: flex;
      justify-content: space-between;
      box-sizing: border-box;
      .layout-user {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height:100%;
        i {
          color:#ffffff
        }
        .slide-content {
          width:13px;
          height:8px;
          overflow: hidden;
          position: relative;
          .slide {
            position: absolute;
            left:-3px;
            top:-30px;
            font-size:12px;
            padding-left:6px;
            color:#ffffff;
          }
        }
      }
    }
    .Yun-nav {
      width:100%;
      height:121px;
      background:rgba(255,255,255,1);
      box-shadow:0px 2px 2px 0px rgba(0,0,0,0.1);
      .Yun-nav-container {
        width:100%;
        height:100%;
        padding:0 158px;
        padding-top:10px;
        box-sizing:border-box;
        .Yun-space {
          width:42px;
          height:20px;
          font-size:14px;
          font-family:PingFang-SC-Medium;
          color:rgba(169,169,170,1);
          line-height:20px;
          cursor: pointer;
        }
        .Yun-page {
          // width:38px;
          height:31px;
          padding-top:23px;
          font-size:26px;
          font-family:Helvetica;
          color:rgba(32,32,32,1);
          line-height:31px
        }
        .Yun-shareSpace {
          height:100%;
          display: flex;
          justify-content: flex-end;
          align-items: center;
          .Yun-space-Pos {
            position: relative;
          }
          .Yun-space-pop {
            position: absolute;
            width:350px;
            top:60px;
            left:-116px;
            background: #fff;
            z-index:1;
            box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);
            &::after {
              box-sizing: content-box;
              width: 0px;
              height: 0px;
              position: absolute;
              top: -18px;;
              right:176px;
              padding:0;
              border-bottom:9px solid #e0e0e0;
              border-top:9px solid transparent;
              border-left:9px solid transparent;
              border-right:9px solid transparent;
              display: block;
              content:'';
              z-index:10
            }
            &::before {
              box-sizing: content-box;
              width: 0px;
              height: 0px;
              position: absolute;
              top: -16px;;
              right:177px;
              padding:0;
              border-bottom:8px solid #FFFFFF;
              border-top:8px solid transparent;
              border-left:8px solid transparent;
              border-right:8px solid transparent;
              display: block;
              content:'';
              z-index: 12;
            }
            .inner {
              border-bottom:1px solid #efefef;
              display: flex;
              justify-content: space-around;
              -webkit-box-align: center;
              align-items: center;
              padding: 10px 15px;
              box-sizing: border-box;
              .font-box {
                width: 23%;
                .font-sty {
                  font-size: 12px;
                  color: #a9a9a9;
                }
              }
              .Yun-space-intived {
                width: 76%;
                .invite-name {
                  color: #333;
                  font-size: 12px;
                }
                .invite-email {
                  color: #a9a9a9;
                  font-size: 12px;
                  padding-top: 5px
                }
              }
              i {
                font-size: 16px;
                color: #a9a9a9;
                padding-right: 17px;
                flex: 1;
              }
            }
            .Yun-space-pop-header {
              border-bottom:1px solid #efefef;
              &>div {
                display: flex;
                justify-content: space-around;
                align-items: center;
                padding:15px;
                box-sizing: border-box;
                .Yun-space-pop-input {
                  flex: 1;
                  display: flex;
                  justify-content: flex-start;
                  align-items: center;
                }
                i {
                  font-size:16px;
                  color: #a9a9a9;
                  padding-right:10px;
                }
                .ivu-dropdown-rel>a {
                  font-size:12px;
                  color:#a9a9a9;
                }
              }
            }
            .Yun-space-invite {
              display: flex;
              justify-content: flex-end;
              padding:15px;
              // padding-top:60px;
              box-sizing:border-box;
              button {
                background: #2D8CF0;
                color:#fff;
                padding:8px 30px;
              }
            }
            .Yun-space-start {
              position: absolute;
              top:10px;
              left:43%;
              width:10px;
              height:10px;
              background: #ddd;
            }
          }
          .Yun-space-list {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            cursor: pointer;
            &:hover span {
              color:#00A1FF;
            }
            span {
              padding-top:10px;
              font-size:12px;
              font-family:PingFangSC-Regular;
              color:rgba(169,169,170,1);
              line-height:17px;
            }
            i {
              color:#00A1FF;
              font-size:22px;
              display: block;
            }
          }
          .Yun-space-More-pop {
            position:relative;
            &:hover .More-pop {
              display:block;
            }
            .More-pop {
              position: absolute;
              display: none;
              width:130px;
              top:60px;
              left:-24px;
              background: #fff;
              z-index:1;
              box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);
              cursor: pointer;
              &>p {
                font-size: 14px;
                color: #a9a9a9;
                text-align: center;
                padding:10px;
              }
              &::after {
                box-sizing: content-box;
                width: 0px;
                height: 0px;
                position: absolute;
                top: -18px;;
                right:56px;
                padding:0;
                border-bottom:9px solid #e0e0e0;
                border-top:9px solid transparent;
                border-left:9px solid transparent;
                border-right:9px solid transparent;
                display: block;
                content:'';
                z-index:10
              }
              &::before {
                box-sizing: content-box;
                width: 0px;
                height: 0px;
                position: absolute;
                top: -16px;;
                right:57px;
                padding:0;
                border-bottom:8px solid #FFFFFF;
                border-top:8px solid transparent;
                border-left:8px solid transparent;
                border-right:8px solid transparent;
                display: block;
                content:'';
                z-index: 12;
              }
            }
          }
        }
      }
    }
</style>

<template>
  <div class="cloundbox">
    <div style="width:100%;height:100%">
      <span @click="fly">云空间</span>
      <span v-if="pathShow">/</span>
        <Tooltip content="新建文件夹">
          <span @click.stop="popAddProject" v-if="pathShow" style=" width: 20px; margin-left:5px;"><Icon type="plus-round" size="16" color="#A9A9AA"></Icon></span>
        </Tooltip>
        <Tooltip content="新建文件夹">
          <span @click.stop="popAddProject" v-if="pathShow" style="width: 20px; margin: 0"><Icon type="folder" size="16" color="#A9A9AA"></Icon></span>
        </Tooltip>
      <!-- 弹出添加项目 -->
      <create v-show="modal"/>
    </div>
  </div>
</template>

<script>
import create from './create'
export default {
  name: 'cloundConponent',
  data () {
    return {
      modal: this.$store.state.createTo,
      pathShow: false
    }
  },
  created () {
    this.pathShow = true
  },
  methods: {
    fly: function () {
      this.$router.push({
        path: '/'
      })
    },
    popAddProject: function () {
      this.$store.dispatch('createTo', true)
      this.$data.modal = true
    }
  },
  components: {
    create
  },
  computed: {
    createToChange () {
      return this.$store.state.createTo
    }
  },
  watch: {
    createToChange (newVal, oldVal) {
      this.$data.modal = newVal
    },
    $route: function (newVal) {
      if (newVal.path === '/') {
        this.pathShow = true
      } else {
        this.pathShow = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.cloundbox{
  height:40px;
  background:rgba(255,255,255,1);
  span{
    display: block;
    float: left;
    height: 40px;
    line-height: 40px;
    text-align: center;
    cursor: pointer;
    color: rgb(169, 169, 170);
    &:hover i {
      color:rgb(0, 161, 255) !important;
    }
  }
  span:nth-of-type(1){
    margin-left: 167px;
    width:45px;
    font-size:13px;
    font-family:PingFang-SC-Medium;
    color:rgba(169,169,170,1);
  }
  span:nth-of-type(2) {
    line-height: 42px;
  }
  span:nth-of-type(3){
    width: 20px;
    margin-left:5px;
  }
  span:nth-of-type(4){
    width: 20px;
  }
}
</style>

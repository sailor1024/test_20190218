<style lang="scss">
//查找页面第一步
.account-findStep1{
  padding-top:16px;
  // 输入手机号码
  .login-find-tip{
    font-size:12px;
    padding-top:18px;
    padding-bottom:3px;
    .login-find-phoneInput{
      display:flex;
      justify-content:space-between;
      margin-bottom:16px;
    }
  }
  // 获取验证码后显示的消息
  .countDown{
    height:32px;
    margin-bottom:8px;
    p{
      font-size:14px;
      color:#999;
    }
  }
  // 主标题
  .account-title{
    font-size:24px;
    font-weight:400;
    line-height:1.3333333333;
    font-family: 'Google Sans',arial,sans-serif;
    color:#000;
  }
  .login-accountname{
    display:flex;
    min-height:24px;
    justify-content: space-between;
    padding-top:32px;
    //  头像样式
    .login-avatar{
      flex:1;
      img{
        width:36px;
        height:36px;
        border-radius:50%;
      }
      div{
        width:36px;
        height:36px;
        border-radius:50%;
      }
      svg{
        width:36px;
        height:36px;
        border-radius:50%;
      }
    }
    //  账号文本样式
    .login-accountname-text{
      flex:4;
      letter-spacing: .25px;
      font-size:14px;
      height:32px;
      line-height:32px;
      color:#212121;
      border:none;
      outline:none;
    }
  }
  // 输入手机号码
  .login-find-tip{
    font-size:12px;
    padding-top:18px;
    padding-bottom:3px;
    .login-find-phoneInput{
      display:flex;
      justify-content:space-between;
      margin-bottom:16px;
    }
  }
  // 获取验证码后显示的消息
  .countDown{
    height:32px;
    margin-bottom:8px;
    p{
      font-size:14px;
      color:#999;
    }
  }
  // 最底下按钮
  .login-utilities{
    display:flex;
    justify-content: space-between;
    margin-top:32px;
    .login-utilities-left{
      text-align:left;
      a{
        font-size:14px;
      }
    }
     .login-utilities-right{
      text-align:right;
    }
  }
}
</style>

<template>
  <div class="account-findStep1">
    <h1 class="account-title">
      账号恢复
    </h1>
    <div class="login-accountname">
      <div class="login-avatar">
        <div v-html="account.svg" style="background:transparent"></div>
        <img :src="account.avatarUrl" alt="">
      </div>
      <input type="text"  class="login-accountname-text" placeholder="请输入手机号" v-model="account.p" autocomplete="new-password">
    </div>
    <div class="login-find-tip">
      <div class="login-find-phoneInput account-form">
        <text-input label="输入验证码">
          <input type="text" slot="cw-input-0609" class="cw-dc-input" v-model="code">
        </text-input>
        <Button :type="type" :disabled="disabled" style="flex:1;height:36px;position:relative;top:10px;margin-left:8px;" @click="getCode()">获取验证码</Button>
      </div>
    </div>
    <div class="countDown" v-show="showMsg">
      <p>{{'验证码'+number+'秒后过期'}}</p>
    </div>
    <div class="login-utilities">
      <div class="login-utilities-left">
        <a href="javascript;" @click.prevent="toLogin()">返回登陆页</a>
      </div>
      <div class="login-utilities-right">
        <Button type="primary" size="large" @click="toFindStep2()">下一步</Button>
      </div>
    </div>
  </div>
</template>

<script>
//  引入输入框组件
import textInput from '../common/input'
export default {
  components: {
    textInput
  },
  watch: {
    'number': function (val) {
      if (val <= 0) {
        clearInterval(this.timer)
        this.timer = null
        this.disabled = false
        this.type = 'primary'
        this.showMsg = false
      }
    }
  },
  data: function () {
    return {
      number: 0, //  倒数
      showMsg: false,
      timer: null,
      account: {p: '', avatarUrl: '', svg: ''}, // 用户名和头像，avatarUrl为空则自动随机生成一个
      phone: '',
      code: '',
      captcha: '=11111=',
      disabled: false,
      type: 'primary'
    }
  },
  created: function () {
    let userlist = localStorage.getItem('userList')
    if (userlist !== null) {
      this.account = JSON.parse(localStorage.getItem('userList'))[0]
      this.account.p = ''
    } else {
      this.account = this.$route.query
      this.account.p = ''
    }
  },
  destroyed: function () {
    if (this.timer != null) {
      //  清除定时器
      clearInterval(this.timer)
      this.timer = null
    }
  },
  methods: {
    //  找回密码步骤1，验证码正确后跳转
    toFindStep2: function () {
      if (this.code === '') {
        this.$Message.error('请输入验证码')
      } else if (this.code !== this.captcha) {
        this.$Message.error('您输入的验证码错误')
      } else {
        this.$router.push({
          path: '/account/findStep2',
          params: {
            account: this.account
          }
        })
      }
    },
    //  获取验证码
    getCode: function () {
      if (this.showMsg) {
        return false
      } else {
        this.getcaptche()
      }
    },
    getcaptche () {
      this.$http.post('index/user/captche_code', {
        'phone': this.account.p
      }).then((res) => {
        let data = res.data
        if (data.code === 1) {
          this.captcha = data.data.captche
          this.$Message.info('验证码已发送，请在60秒内输入')
          this.showMsg = true
          this.disabled = true
          this.type = 'default'
          this.number = 60
          this.count(60)
        } else {
          this.$Message.error('超出当天验证码次数限制')
        }
      }).catch(() => {
      })
    },
    // 定时器
    count (num) {
      if (num > 0) {
        this.timer = setInterval(() => {
          this.number -= 1
        }, 1000)
      } else {
        clearInterval(this.timer)
        this.timer = null
      }
    },
    //  返回登陆页
    toLogin: function () {
      this.$router.push('/account/login')
    }
  }
}
</script>

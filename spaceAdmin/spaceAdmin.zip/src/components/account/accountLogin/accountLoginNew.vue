<style lang="scss">
.account-login{
  padding-top:16px;
  position: relative;
    // 输入手机号码
  .login-find-tip{
    font-size:12px;
    padding-bottom:3px;
    .login-find-phoneInput{
      display:flex;
      justify-content:space-between;
      margin-bottom:16px;
    }
  }
  // 获取验证码后显示的消息
  .countDown{
    height:32px;
    margin-bottom:8px;
    p{
      font-size:14px;
      color:#999;
    }
  }
  .login-change {
    position: absolute;
    width: 2.5rem;
    height:2.5rem;
    right:0;
    top:14px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    // &.active {
    //   background-position: -40px -40px;
    // }
    i {
      font-size:20px;
      color:#00a1ff;
    }
  }
  .account-title{
    font-size:24px;
    font-weight:400;
    line-height:1.3333333333;
    font-family: 'Google Sans',arial,sans-serif;
    color:#000;
    user-select: none;
  }
  .login-accountname{
    padding-top:32px;
  }
  .login-accountname,.login-passwd{
    margin-bottom:16px;
  }
  //底端容器样式
  .login-accountname-new{
    min-height:24px;
    padding-top:8px;
    margin-top:24px;
  }
  .account-utilities-new{
    display:flex;
    justify-content: space-between;
    margin-top:32px;
    .account-utilities-left{
      text-align:left;
      a{
        font-size:14px;
      }
      .account-toLoginExists{
        font-size:12px;
      }
    }
    .account-utilities-right{
      text-align:right;
      a{
        font-size:12px !important;
      }
    }
  }
}
</style>

<template>
  <div class="account-login">
    <div class="login-change" @click="loginWayChange">
      <i class="font_family icon-31" v-if="codeShow" title="账号密码登陆"></i>
      <i class="font_family icon-phone" v-if="PcShow" title="验证码登录"></i>
    </div>
    <h1 class="account-title">
      登陆
    </h1>
    <div class="login-accountname account-form" v-if="PcShow">
      <text-input label="手机号码/邮箱">
        <input type="text" slot="cw-input-0609" class="cw-dc-input" v-model="phone" @keyup="keyup" autocomplete="new-password">
      </text-input>
    </div>
    <div class="login-passwd account-form" v-if="PcShow">
      <text-input label="密码">
        <input autocomplete="new-password" :type="inputtype" slot="cw-input-0609" class="cw-dc-input" v-model="password" @keyup="keyup">
      </text-input>
    </div>
    <div class="login-accountname account-form" v-if="codeShow">
      <text-input label="手机号码">
        <input type="text" slot="cw-input-0609" class="cw-dc-input" v-model="codePhone" autocomplete="new-password">
      </text-input>
    </div>
    <div class="login-find-tip" v-if="codeShow">
      <div class="login-find-phoneInput account-form">
        <text-input label="输入验证码">
          <input type="text" slot="cw-input-0609" class="cw-dc-input" v-model="code" autocomplete="new-password">
        </text-input>
        <Button :type="type" :disabled="disabled" style="flex:1;height:36px;position:relative;top:10px;margin-left:8px;" @click="getCode()">获取验证码</Button>
      </div>
    </div>
    <div class="countDown" v-show="showMsg">
      <p>{{'验证码'+number+'秒后过期'}}</p>
    </div>
    <div class="account-utilities-new">
      <div class="account-utilities-left">
        <a href="javascript;" @click.prevent="toLoginExists()" class="account-toLoginExists">登陆现有账号</a>
      </div>
      <div class="account-utilities-right">
        <a href="javascript;" @click.prevent="toFind()">忘记密码？</a>
      </div>
    </div>
    <div class="account-utilities-new">
      <div class="account-utilities-left">
        <a href="javascript;" @click.prevent="toRegister()">注册账号</a>
      </div>
      <div class="account-utilities-right">
        <Button type="primary" size="large" @click.stop="loginfunc()">下一步</Button>
      </div>
    </div>
  </div>
</template>

<script>
//  引入头像库
import Avatars from '@dicebear/avatars'
import SpriteCollection from '@dicebear/avatars-identicon-sprites'
//  引入输入框组件
import textInput from '../common/input'
//  缓存中没账号信息加载此页****************************************
export default {
  components: {
    textInput
  },
  data: function () {
    return {
      phone: '',
      codePhone: '',
      password: '',
      inputtype: 'text',
      number: 0,
      code: '',
      showMsg: false,
      codeShow: false,
      PcShow: true,
      timer: null,
      account: {p: '', avatarUrl: '', svg: ''},
      captcha: '=11111=',
      userMsg: '',
      disabled: false,
      type: 'primary'
    }
  },
  created: function () {
    let pro = new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve()
      }, 1000)
    })
    pro.then(() => {
      this.inputtype = 'password'
    })
  },
  methods: {
    // 键盘事件
    keyup (e) {
      if (e.keyCode === 13) {
        this.loginfunc()
      }
    },
    loginWayChange (e) {
      let condition = e.currentTarget.classList.value.indexOf('active')
      if (condition === -1) {
        this.PcShow = false
        this.codeShow = true
        e.currentTarget.classList.add('active')
      } else {
        this.PcShow = true
        this.codeShow = false
        e.currentTarget.classList.remove('active')
      }
    },
    // 定时器
    count (num) {
      if (num > 0) {
        this.timer = setInterval(() => {
          this.number -= 1
        }, 1000)
      } else {
        clearInterval(this.timer)
        this.timer = null
      }
    },
    //  获取验证码
    getCode: function () {
      if (!this.codePhone) {
        this.$Message.error('请输入电话号码')
        return false
      }
      //  验证手机格式
      let regPhone = /^1[0-9]{10}$/
      if (!regPhone.test(this.codePhone)) {
        this.$Message.error('手机号格式不正确')
        return false
      }
      if (this.showMsg) {
        return false
      } else {
        this.$http.post('index/user/phonecode', {
          // 'phone': this.account.p,
          'logincode': this.codePhone
        }).then((res) => {
          if (res.data.data.code) {
            this.captcha = res.data.data.phonecode
            this.$Message.info('验证码已发送，请在60秒内输入')
            this.showMsg = true
            this.disabled = true
            this.type = 'default'
            this.number = 60
            this.count(60)
          } else {
            this.$Message.error('超出当天验证码次数限制')
          }
        })
      }
    },
    //  使用现有账号登陆
    toLoginExists: function () {
      let accounts = JSON.parse(localStorage.getItem('userList'))
      if (accounts === null) {
        this.$Message.error('没有保存的现有账号，请重新登录')
        return false
      }
      this.$router.push('/account/loginExists')
    },
    //  跳转到找回账号页
    toFind: function () {
      //  生成随机头像
      let avatars = new Avatars(SpriteCollection)
      let svg = avatars.create()
      this.$router.push({
        path: '/account/findStep1',
        query: {
          avatarUrl: '',
          p: this.phone,
          svg: svg
        }
      })
    },
    //  跳转到注册页
    toRegister: function () {
      this.$router.push('/account/register')
    },
    //  登陆功能
    loginfunc: function () {
      if (!this.codeShow) {
        //  验证用户名，密码是否为空
        if (this.phone === '') {
          this.$Message.error('请输入手机号')
          return false
        } else if (this.password === '') {
          this.$Message.error('请输入密码')
          return false
        }
        //  验证手机格式
        // var regPhone = /^1[0-9]{10}$/
        // if (!regPhone.test(this.phone)) {
        //   this.$Message.error('手机号格式不正确')
        //   return false
        // }
        //  验证密码格式
        var regPwd = /^[\w@0-9]{8,}$/
        if (!regPwd.test(this.password)) {
          this.$Message.error('密码格式不正确')
          return false
        }
        this.$http.post('index/user/user_login', {
          'phone': this.phone,
          'password': this.password
        }).then((res) => {
          let data = res.data
          if (data.code === 1) {
            let obj = data.data
            this.$store.dispatch('userInfo', obj)
            //  更新用户信息缓存
            this.updateUserList(this.phone)
            this.$router.push({
              path: '/'
            })
          } else {
            this.$Message.error('账号或密码错误')
          }
        })
      } else {
        //  验证手机格式
        let regPhone = /^1[0-9]{10}$/
        if (!regPhone.test(this.codePhone)) {
          this.$Message.error('手机号格式不正确')
          return false
        }
        if (this.codePhone === '') {
          this.$Message.error('请输入手机号')
          return false
        } else if (this.code === '') {
          this.$Message.error('请输入验证码')
          return false
        } else if (parseInt(this.code) !== this.captcha) {
          this.$Message.error('您输入的验证码错误')
          return false
        } else {
          this.$http.post('index/user/check_userinfo', {
            'phone': this.codePhone
          }).then((res) => {
            console.log(res)
            this.userMsg = res.data.data.data
            if (res.data.data.code === 1) {
              this.$store.dispatch('userInfo', this.userMsg)
              //  更新用户信息缓存
              this.updateUserList(this.codePhone)
              this.$router.push({
                path: '/'
              })
            } else {
              this.$Message.error('登录失败，请检查你的账号')
            }
          })
        }
      }
    },
    //  将用户信息缓存
    updateUserList: function (phone) {
      //  生成随机头像
      let avatars = new Avatars(SpriteCollection)
      let svg = avatars.create()
      this.svg = svg
      //  如果之前localStorage中有userList,登陆时操作localStorage进去
      if (localStorage.getItem('userList')) {
        var userList = JSON.parse(localStorage.getItem('userList'))
        var isExists = false
        //  遍历localStorage数组查看是否已有该用户
        for (var i = 0; i < userList.length; i++) {
          if (phone === userList[i].p) {
            isExists = true
            //  该用户存在，则深克隆对象，localStorage数组换位
            var temp = JSON.parse(JSON.stringify((userList[i])))
            userList.splice(i, 1)
            userList.unshift(temp)
            //  更新localStorage
            localStorage.setItem('userList', JSON.stringify(userList))
            break
          }
        }
        if (isExists === false) {
          //  该用户不存在则创建新对象，unshift
          userList.unshift({p: phone, svg: svg, avatarUrl: ''})
          localStorage.setItem('userList', JSON.stringify(userList))
        }
      } else { //  没有则创建新,每个用户对应一个默认svg头像和可自定义头像
        localStorage.setItem('userList', JSON.stringify([{p: phone, svg: svg, avatarUrl: ''}]))
      }
    }
  },
  watch: {
    number (newVal) {
      if (newVal <= 0) {
        clearInterval(this.timer)
        this.timer = null
        this.disabled = false
        this.type = 'primary'
        this.showMsg = false
      }
    }
  }
}
</script>

<style lang="scss">
//  用户登陆页容器
.account{
   min-height:100vh;
   background:#fff;
   display:flex;
   flex-direction:column;
   justify-content: center;
   font-family: 'PingFangSC';
   .loginBox{
    background:#fff;
    min-height:500px;
    margin:0 auto;
    border-radius: 8px;
    padding:48px 40px;
    box-shadow:0px 0px 0px 0px rgba(155,155,155,.4);
    //  logo样式
    .logo-login{
      img{
        height:24px;
      }
    }
    @media(max-width:600px){
      width:100%;
      min-width:332px;
      display:block;
    }
    @media(min-width:601px){
      min-width:450px;
      box-shadow:1px 1px 2px 1px rgba(155,155,155,.4);
    }
    //覆盖目录下框架表单样式
    .ivu-input{
      border:1px solid transparent;
      border-bottom-color:#999;
      border-radius:0;
      background:transparent;
      color:#626262;
      font-size:14px;
      transition:all .3s cubic-bezier(.55,0,.55,.2);
      height:auto;
      padding:0;
      margin-top:5px;
      margin-bottom:5px;
    }
    .ivu-input:focus{
      box-shadow: 0 0 0 0 ;
    }
    //覆盖目录下按钮样式
    .ivu-btn-primary{
      background-color:#00a1ff;
      border-color:#00a1ff;
    }
    .ivu-checkbox-checked .ivu-checkbox-inner{
      background-color:#00a1ff;
      border-color:#00a1ff;
    }
    //覆盖目录下a样式
    a{
      color:#00a1ff;
    }
  }
  .account-form{
    margin-bottom:16px;
  }
}
</style>

<template>
  <div class="account">
    <div class="loginBox">
      <!-- logo -->
      <div class="logo-login">
        <img src="@/assets/images/kangyun.png" alt="">
      </div>
      <router-view></router-view>
    </div>
  </div>
</template>

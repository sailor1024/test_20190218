<template>
  <div class="userInset">
    <div class="userInset-header">
      <p>您访问的所有账户和组织的配置文件</p>
      <i-button type="info" @click="change">编辑</i-button>
    </div>
    <div class="name" v-for="(item, index) in nameMsg" :key="index">
      <p class="name-one">{{item.nameTitle}}</p>
      <p class="name-two">{{item.name}}</p>
    </div>
    <!-- forget -->
    <div class="forget">
      <h4>忘了我</h4>
      <div class="delete-user">
        <Icon type="close-circled"></Icon>
        <p>删除账户</p>
        <a href="">了解详情</a>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      nameMsg: [
        {
          nameTitle: '名字',
          name: this.$store.state.userInfo.famailname
        },
        {
          nameTitle: '姓',
          name: this.$store.state.userInfo.lastname
        },
        {
          nameTitle: '标题',
          name: '空'
        },
        {
          nameTitle: '手机号',
          name: this.$store.state.userInfo.phone
        },
        {
          nameTitle: '电子邮件地址',
          name: this.$store.state.userInfo.email
        },
        {
          nameTitle: '密码',
          name: '********'
        }
      ]
    }
  },
  methods: {
    change: function () {
      this.$emit('changeComp', 'editor')
    }
  }
}
</script>
<style scoped lang="scss">
.userInset {
  display: flex;
  flex-direction: column;
  flex: 1;
  background: #fff;
  margin-left:20px;
  padding:30px 20px;
  box-sizing: border-box;
  .userInset-header {
    display: flex;
    height: 65px;
    justify-content: space-between;
    align-items: center;
    padding-bottom:30px;
    border-bottom:3px solid #F1F1F1;
    p {
      color: #9D9E9E;
      font-size:18px;
      font-weight: bold;
    }
    button {
      padding: 6px 36px;
      border-radius: 0;
      background: rgb(0, 161, 255)
    }
  }
  .name {
    margin-top:43px;
    .name-one {
      font-size:16px;
      color:#ADAFAF
    }
    .name-two {
      font-size:14px;
      color: #666364;
      padding-top:5px;
    }
  }
  .forget {
    width:100%;
    margin-top:100px;
    h4 {
      font-size: 20px;
      font-family: 'PingFangSC-Regular';
      color: #0f2d3e;
      font-weight: 800;
      padding-bottom:20px;
    }
    .delete-user {
      border:2px solid #E7E7E8;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      padding:20px;
      i {
        font-size:20px;
        color:#e0e0e0;
      }
      p {
        font-size:16px;
        font-weight: 700;
        color:#666364;
        padding-left:10px;
      }
      a {
        text-decoration: underline;
        font-size:14px;
        padding-left:10px;
      }
    }
  }
}
</style>

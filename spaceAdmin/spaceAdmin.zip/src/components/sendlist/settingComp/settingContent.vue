<template>
  <div class="setting-content">
    <settingLeft />
    <settingRight v-if="show && changeShow === 0" @changeComp="change"/>
    <settingPrivacy v-else-if="changeShow === 1"/>
    <settingSpace v-else-if="changeShow === 2"/>
    <settingRightEditor v-else @changeComp="changeIf"/>
  </div>
</template>
<script>
import settingLeft from './settingLeft'
import settingRight from './settingRight'
import settingRightEditor from './settingRightEditor'
import settingPrivacy from './settingPrivacy'
import settingSpace from './settingSpace'
export default {
  data () {
    return {
      show: true,
      changeShow: 0
    }
  },
  computed: {
    settingChange: function () {
      return this.$store.state.settingChange
    }
  },
  watch: {
    settingChange (newVal) {
      this.changeShow = newVal
    }
  },
  methods: {
    change: function (data) {
      this.show = false
    },
    changeIf (data) {
      this.show = true
    }
  },
  components: {
    settingLeft,
    settingRight,
    settingRightEditor,
    settingPrivacy,
    settingSpace
  }
}
</script>
<style scoped lang="scss">
.setting-content {
  margin: 20px 174px 0px 154px;
  display: flex;
  justify-content: space-between;
}
</style>

<template>
  <div class="userMsg">
    <div class="container">
      <p v-for="(item, index) in list" :key="index" @click="change(index)" :class="[active === index ? 'active' : '']">{{item}}</p>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      list: ['用户资料', '隐私', '空间设置'],
      active: 0
    }
  },
  methods: {
    change: function (index) {
      this.$store.dispatch('settingChange', index)
      this.active = index
    }
  }
}
</script>
<style scoped lang="scss">
.userMsg {
  .container {
    display: flex;
    flex-direction: column;
    background: #fff;
    & p:last-child {
      border:0
    }
    p {
      padding:20px;
      background: #fff;
      font-size: 20px;
      font-family: 'PingFangSC-Regular';
      color: #0f2d3e;
      font-weight: 800;
      cursor: pointer;
      &.active {
        color:rgb(0, 161, 255);
      }
    }
    p {
      border-bottom: 1px solid #F1F1F1;
    }
  }
}
</style>

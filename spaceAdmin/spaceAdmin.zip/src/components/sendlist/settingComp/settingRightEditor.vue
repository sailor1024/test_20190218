<template>
  <div class="userInset">
    <div class="userInset-header">
      <p>您访问的所有账户和组织的配置文件</p>
    </div>
    <div class="name" v-for="(item, index) in nameMsg" :key="index">
      <p class="name-one">{{item.nameTitle}}</p>
      <p class="name-two">
        <input :type="item.type" :placeholder="item.name" @focus="focus" @blur="blur" v-model="item.name">
      </p>
    </div>
    <!-- forget -->
    <div class="forget">
      <i-button @click="cancle">取消</i-button>
      <i-button type="primary" @click="updata">更新</i-button>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      nameMsg: [
        {
          nameTitle: '名字',
          name: this.$store.state.userInfo.famailname,
          type: 'text'
        },
        {
          nameTitle: '姓',
          name: this.$store.state.userInfo.lastname,
          type: 'text'
        },
        {
          nameTitle: '手机号',
          name: this.$store.state.userInfo.phone,
          type: 'number'
        },
        {
          nameTitle: '电子邮件地址',
          name: this.$store.state.userInfo.email,
          type: 'email'
        },
        {
          nameTitle: '旧密码*',
          name: '********',
          type: 'password'
        },
        {
          nameTitle: '新密码*',
          name: '',
          type: 'password'
        },
        {
          nameTitle: '确认密码*',
          name: '',
          type: 'password'
        }
      ],
      postMsg: {}
    }
  },
  methods: {
    updata () {
      // 获取用户输入的信息
      let arr = this.nameMsg
      this.postMsg = {
        name: arr[0].name,
        nameFirst: arr[1].name,
        number: arr[2].name,
        email: arr[3].name,
        newPassword: arr[5].name,
        confirmPassword: arr[6].name,
        user_id: this.$store.state.userInfo.id
      }
      // //  验证密码格式
      // var regPwd = /^[\w@0-9]{8,}$/
      // if (!regPwd.test(this.postMsg.newPassword)) {
      //   this.$Message.error('密码格式不正确')
      //   return
      // }
      if (this.postMsg.newPassword !== this.postMsg.confirmPassword) {
        this.$Message.error('两次输入的密码不正确')
        return
      }
      // 发送请求
      this.$http.post('/index/user/editor', this.postMsg).then((res) => {
        if (res.data.code === 1) {
          this.$Message.info('修改成功')
          this.$store.dispatch('userInfo', res.data.data[0])
          setTimeout(() => {
            this.$router.push({
              path: '/'
            })
          }, 20)
          // 把修改成功返回的对象渲染到视图上
        } else {
          this.$Message.error('修改失败:' + res.data.data.info)
        }
      })
    },
    focus (e) {
      e.target.parentNode.style['border-bottom-color'] = 'rgb(0, 161, 255)'
      e.target.parentNode.previousElementSibling.style.color = 'rgb(0, 161, 255)'
    },
    blur (e) {
      e.target.parentNode.style['border-bottom-color'] = '#E8E8E8'
      e.target.parentNode.previousElementSibling.style.color = '#ADAFAF'
    },
    cancle () {
      this.$emit('changeComp', 'show')
    }
  }
}
</script>
<style scoped lang="scss">
.userInset {
  display: flex;
  flex-direction: column;
  flex: 1;
  background: #fff;
  margin-left:20px;
  padding:30px 20px;
  box-sizing: border-box;
  .userInset-header {
    display: flex;
    height:65px;
    justify-content: space-between;
    align-items: center;
    padding-bottom:30px;
    border-bottom:3px solid #F1F1F1;
    p {
      color: #9D9E9E;
      font-size:18px;
      font-weight: bold;
    }
  }
  .name {
    margin-top:43px;
    .name-one {
      font-size:16px;
      color:#ADAFAF;
      transition: all .3s ease;
    }
    .name-two {
      font-size:14px;
      color: #666364;
      padding-top:5px;
      border-bottom:2px solid #E8E8E8;
      padding-bottom:5px;
      transition: all .3s ease;
      input {
        width:100%;
        font-size:14px;
        color:#666364;
        border: none;
        &:focus {
          outline: none;
        }
      }
    }
  }
  .forget {
    width:100%;
    margin-top:40px;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    button {
      padding:6px 40px;
      border-radius: 0;
      &:nth-child(2) {
        margin-left:20px;
        background: rgb(0, 161, 255);
      }
    }
  }
}
</style>

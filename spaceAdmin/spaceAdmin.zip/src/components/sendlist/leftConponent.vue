<template>
  <div class="sendlist">
    <sendmenue />
    <sendlistConponent :list="list"/>
  </div>
</template>

<script>
import sendlistConponent from './sendlistConponent'
import sendmenue from './sendmenue'
export default {
  name: 'sendleftConponent',
  props: ['list'],
  components: {
    sendlistConponent,
    sendmenue
  }
}
</script>

<style lang="scss" scoped>
</style>

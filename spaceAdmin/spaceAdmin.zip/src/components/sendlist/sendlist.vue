<template>
  <div class="sendlist">
    <div class="sendbox">
      <div class="leftbox">
        <header>
          <h4>公共空间</h4>
          <div class="rightbox">
            <sendrightConponent :list="count" />
          </div>
        </header>
        <sendleftConponent :list="list" />
      </div>
    </div>
    <nosoureComponent v-if="issoure" />
    <ItemListPage v-else :count="count" @pagechange="sourechange"/>
  </div>
</template>

<script>
import sendrightConponent from './rightConponent'
import sendleftConponent from './leftConponent'
import nosoureComponent from '@/components/common/nosoureComponent'
import ItemListPage from '@/components/list/itemlist/ItemListPage'
export default {
  name: 'sendlistConponent',
  data () {
    return {
      'list': [],
      issoure: false,
      count: ''
    }
  },
  computed: {
    publicProjectChange () {
      return this.$store.state.publicProject
    }
  },
  watch: {
    publicProjectChange (newVal) {
      if (newVal === true) {
        this.load(1)
        this.$store.dispatch('publicProject', false)
      }
    }
  },
  methods: {
    sourechange (page) {
      this.load(page)
    },
    load (page = 1) {
      this.$http.post('index/index/has_send_list', {
        'userid': this.$store.state.userInfo.id,
        'page': page,
        'phone': this.$store.state.userInfo.phone
      }).then((res) => {
        let data = res.data
        if (data.code === 1) {
          this.list = data.data.data
          this.count = data.data.num
          if (this.list.length === 0) this.issoure = true
        } else {
          this.$Message.error('你没有发布的项目')
          this.issoure = true
        }
      }).catch((err) => {
        console.log(err)
        this.$Message.error('出错了,请重试')
      })
    }
  },
  created () {
    this.load()
  },
  components: {
    sendleftConponent,
    sendrightConponent,
    nosoureComponent,
    ItemListPage
  }
}
</script>

<style lang="scss" scoped>
.sendlist{
  padding-bottom: 20px;
  .sendbox{
    margin: 0px 155px;
    display: flex;
    @media screen and (max-width: 1120px) {
      margin: 0px 70px;
    }
    .leftbox{
      flex: 1;
      header{
        display: flex;
        justify-content: space-between;
        align-items: center;
        h4{
          margin-top: 40px;
          margin-bottom: 31px;
          height:37px;
          font-size:26px;
          font-family:PingFangSC-Regular;
          color:rgba(15,45,62,1);
          line-height:37px;
        }
      }
    }
  }
}

@media screen and (max-width: 1100px) {
  .rightbox{
    width: 120px !important;
  }
}
</style>

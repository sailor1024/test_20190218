<template>
  <Dropdown class="menue" @on-click="select" trigger="click">
      <a style="color: rgb(98, 98, 98)" href="javascript:void(0)">
          {{res}}
          <Icon class="icon" type="arrow-down-b" color="rgb(98, 98, 98)" size="16px"></Icon>
      </a>
      <DropdownMenu slot="list">
          <DropdownItem name="创建日期" class="slide">创建日期</DropdownItem>
          <DropdownItem name="名称" class="slide">名称</DropdownItem>
      </DropdownMenu>
  </Dropdown>
</template>

<script>
export default {
  name: 'sendmenue',
  data () {
    return {
      res: '创建日期'
    }
  },
  methods: {
    select: function (name) {
      this.res = name
    }
  }
}
</script>

<style lang="scss" scoped>
.menue{
  font-size:14px;
  font-family:PingFangSC-Regular;
  color:rgba(98,98,98,1);
  margin-left: 14px;
  padding: 8px 0px 9px 0px;
  a{
    .icon{
      transform: rotate(180deg);
    }
  }
  a:hover{
    transform: rotate(0deg);
  }
  .slide {
    border-bottom:1px solid #e0e0e0 !important;
  }
  .slide:hover {
    color: rgb(0, 161, 255)
  }
  .slide:last-child {
    border-bottom:0 !important;
  }
}
</style>

<template>
  <li>
    <div class="sendbox" @click.stop="gotodetilfunc">
      <div class="boxitem">
        <div class="left">
          <i :style="backimg"></i>
        </div>
        <div class="right">
          <div style="padding-bottom:10px;padding-top:10px;font-size:18px">{{json.title}}</div>
          <p>{{desbute}}</p>
        </div>
        <div class="icon-suo">
          <Icon type="unlocked" @click.stop="pop"></Icon>
        </div>
      </div>
    </div>
    <pop v-if="popShow" @clickNone="none" :giveData="{title: json.title, id: json.id}" :shareShow="true"/>
  </li>
</template>

<script>
import pop from '../common/header/headComp/pop'
export default {
  data () {
    return {
      popShow: false
    }
  },
  props: ['json'],
  name: 'sendlistitem',
  components: {
    pop
  },
  computed: {
    desbute () {
      return '由' + this.json.niname + '创建于' + this.format(this.json.create_time)
    },
    backimg () {
      return {
        'backgroundImage': 'url(' + this.$imgURL + this.json.marker_image + ')'
      }
    }
  },
  methods: {
    gotodetilfunc () {
      this.$router.push({
        path: '/home',
        query: {
          id: this.json.id
        }
      })
    },
    pop () {
      this.$store.dispatch('popTo', false)
      this.popShow = true
    },
    none (data) {
      this.popShow = data
    },
    format (time) {
      let date = new Date(time * 1000)
      let y = date.getFullYear() + ''
      let m = date.getMonth() + 1
      let d = date.getDate()
      m = m > 10 ? m : '0' + m
      d = d > 10 ? d : '0' + d
      return y + '年' + m + '月' + d + '日'
    }
  }
}
</script>

<style lang="scss" scoped>
.sendbox{
  height: 100px;
  border-top: 1px solid #E7E7E7;
  background-color: white;
  padding: 16px 33px;
  .boxitem{
    display: flex;
    .left{
      width: 100px;
      i{
        display: block;
        width: 100px;
        height: 70px;
        background-position: center center;
        background-repeat: no-repeat;
        background-size: cover;
        background-color: '#D8D8D8'
      }
    }
    .right{
      flex: 1;
      margin-left: 15px;
      h4{
        height:25px;
        font-size:18px;
        font-family:PingFang-SC-Medium;
        color:rgba(15,45,62,1);
        line-height:25px;
        margin-top: 12px;
      }
      p{
        height:20px;
        font-size:14px;
        font-family:PingFangSC-Regular;
        color:rgba(98,98,98,1);
        line-height:20px;
      }
    }
    .icon-suo {
      display: flex;
      align-items: center;
      i {
        color: #0f2d3e;
        font-size:20px;
      }
    }
  }
}
</style>

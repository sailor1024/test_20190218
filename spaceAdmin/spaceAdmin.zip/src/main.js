// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import iView from 'iview'
import store from './store'
import axios from 'axios'
import 'iview/dist/styles/iview.css'
// 引入icon
import './assets/iconfont/iconfont.css'
// 引入reset.css
import './components/reset/reset.css'
// 引入复制插件
import VueClipboard from 'vue-clipboard2'
import '../node_modules/babel-polyfill/dist/polyfill.js'
Vue.use(iView)
Vue.use(VueClipboard)
Vue.config.productionTip = false
const isdev = false
if (isdev) {
  axios.defaults.baseURL = 'http://localhost/spacephp/public/index.php'
  Vue.prototype.$imgURL = 'http://localhost/spacephp/public/'
} else {
  axios.defaults.baseURL = 'https://todo.kangyun3d.cn/index.php'
  Vue.prototype.$imgURL = 'https://todo.kangyun3d.cn/'
}

Vue.prototype.$http = axios

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})

const getters = {
  userInfo (state) {
    return state.userInfo
  }
}
export default getters

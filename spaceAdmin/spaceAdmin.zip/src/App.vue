<template>
  <div id="app">
    <!-- <Upload action="http://localhost/spacephp/public/index.php/index/upload/file_test">
        <Button type="ghost" icon="ios-cloud-upload-outline">Upload files</Button>
    </Upload> -->
    <router-view v-if="isRouterActive"/>
    <!-- <div class="box">
      <div class="uploadbox">
        <Input v-model="uuid" placeholder="uuid" style="width: 300px"></Input>
        <Upload action="//todo.kangyun3d.com/index.php/index/upload/upload_file" name='file' :data="obj">
          <Button type="ghost" icon="ios-cloud-upload-outline">选择文件</Button>
        </Upload>
      </div>
    </div> -->
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      uuid: '',
      isRouterActive: true
    }
  },
  provide: {
    isReload: 'save'
  },
  watch: {
    isRouterReload: function (newVal) {
      this.reload()
    }
  },
  methods: {
    reload () {
      this.isRouterActive = false
      this.$nextTick(function () {
        this.isRouterActive = true
        this.$store.dispatch('isRouterReload', false)
      })
    }
  },
  computed: {
    isRouterReload () {
      return this.$store.state.isRouterReload
    },
    obj () {
      return {
        'name': this.uuid
      }
    }
  },
  mounted () {
    this.$store.dispatch('userInfo', JSON.parse(localStorage.getItem('userInfo')))
  }
}
</script>

<style lang="scss">
html{
  font-family: -apple-system,BlinkMacSystemFont,PingFang\ SC,Helvetica\ Neue,STHeiti,Microsoft\ Yahei,Tahoma,Simsun,sans-serif;
}
body {
  background: #efefef !important;
  &.bodyOf::-webkit-scrollbar {
    display: none;
    // width:8px;
  }
  &.bodyOf::-webkit-scrollbar-thumb {
    background: #495060;
  }
}
</style>

import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/account',
      component: function (resolve) {
        require.ensure([], function () {
          resolve(require('@/components/account/account'))
        })
      },
      children: [
        {
          path: '/',
          name: 'accountDef',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/account/accountLogin/accountLoginNew'))
            })
          }
        },
        {
          path: '/account/login',
          name: 'accountLogin',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/account/accountLogin/accountLoginNew'))
            })
          }
        },
        {
          path: '/account/accountFinsh',
          name: 'accountFinsh',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/account/accountRegister/accountFinsh'))
            })
          }
        },
        {
          path: '/account/loginExists',
          name: 'accountExists',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/account/accountLogin/accountLoginExists'))
            })
          }
        },
        {
          path: '/account/select',
          name: 'accountSelect',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/account/accountSelect/accountSelect'))
            })
          }
        },
        {
          path: '/account/findStep1',
          name: 'accountFindStep1',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/account/accountFind/accountFindStep1'))
            })
          }
        },
        {
          path: '/account/findStep2',
          name: 'accountFindStep2',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/account/accountFind/accountFindStep2'))
            })
          }
        },
        {
          path: '/account/register',
          name: 'accountRegister',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/account/accountRegister/accountRegister'))
            })
          }
        },
        {
          path: '/account/registration',
          name: 'accountRegistration',
          component: function (resolve) {
            require.ensure([], function () {
              resolve(require('@/components/registration/registration'))
            })
          }
        }
      ]
    },
    {
      path: '',
      name: 'listConponent',
      component: function (resolve) {
        require.ensure([], function (require) {
          resolve(require('@/components/list/listConponent'))
        })
      },
      children: [
        {
          path: '/',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/list/itemlist/itemlist'))
            })
          }
        },
        {
          path: '/userlist',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/userlist/userlist'))
            })
          }
        },
        {
          path: '/userMsg',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/userlist/userMsg'))
            })
          }
        },
        {
          path: '/stailist',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/stailist/stailist'))
            })
          }
        },
        {
          path: '/sendlist',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/sendlist/sendlist'))
            })
          }
        },
        {
          path: '/folder/:id',
          name: 'folder',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/list/itemlist/itemListContentComp/itemListFolderContent'))
            })
          }
        }
      ]
    },
    {
      path: '/setting',
      component: function (resolve) {
        require.ensure([], function (require) {
          resolve(require('@/components/sendlist/setting'))
        })
      }
    },
    {
      path: '/home',
      name: 'home',
      component: function (resolve) {
        require.ensure([], function (require) {
          resolve(require('@/components/Home'))
        })
      },
      children: [
        {
          path: '/',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/content/tabone/taboneConponent'))
            })
          },
          children: [
            {
              path: '/',
              component: function (resolve) {
                require.ensure([], function (require) {
                  resolve(require('@/components/content/tabone/view/frameConponent'))
                })
              }
            },
            {
              path: '/home/image',
              component: function (resolve) {
                require.ensure([], function (require) {
                  resolve(require('@/components/content/tabone/view/imageConponent'))
                })
              }
            },
            {
              path: '/home/video',
              component: function (resolve) {
                require.ensure([], function (require) {
                  resolve(require('@/components/content/tabone/view/videoConponent'))
                })
              }
            },
            {
              path: '/home/view',
              component: function (resolve) {
                require.ensure([], function (require) {
                  resolve(require('@/components/content/tabone/view/viewConponent'))
                })
              }
            },
            {
              path: '/home/download',
              component: function (resolve) {
                require.ensure([], function (require) {
                  resolve(require('@/components/content/tabone/view/downloadConponent'))
                })
              }
            }
          ]
        },
        {
          path: '/tabtwo',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/content/tabtwo/tabtwoConponent'))
            })
          }
        },
        {
          path: '/tabthr',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/content/tabthr/tabthrConponent'))
            })
          }
        },
        {
          path: '/tabfou',
          component: function (resolve) {
            require.ensure([], function (require) {
              resolve(require('@/components/content/tabfou/tabfouConponent'))
            })
          }
        }
      ]
    },
    // 空页面
    {
      path: '/embed',
      component: function (resolve) {
        require.ensure([], function (require) {
          resolve(require('@/components/embed'))
        })
      }
    },
    {
      path: '/embedBack',
      component: function (resolve) {
        require.ensure([], function (require) {
          resolve(require('@/components/embedBack'))
        })
      }
    }
  ]
})
router.beforeEach((to, from, next) => {
  if (to.path === '/account/registration' || to.path === '/account' || to.path === '/account/register' || to.path === '/account/loginExists' || to.path === '/account/select' || to.path === '/account/login' || to.path === '/account/findStep1' || to.path === '/account/findStep2' || to.path === '/account/accountFinsh') {
    next()
  } else {
    let userInfo = JSON.parse(localStorage.getItem('userInfo'))
    if (userInfo) {
      next()
    } else {
      next({ path: '/account' })
    }
  }
})

export default router
